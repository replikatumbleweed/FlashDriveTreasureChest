              .,-=~ Sequence ~=-,.
              ~=-,. Dark Side .,-=~ 
===============================
              By Rendom (c) 2005 
===============================
For better appearance use skinned font: Ctrl+P>Classic Skins>Use skinned font for main...

All windows skined
* Main, Equalizer, Playlist
* AVS, Media Library, Video

For Winamp: 2.9x-5.x

Contcat me
web: http://www.rendom.net
mail: rendom@gmail.com
===============================
DO NOT use ANY elements of this skin in ANY your work.
===============================
And thank you for using my skin :)