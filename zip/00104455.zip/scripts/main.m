/*--------------------------------------------------------------------
 Main/Normal player group script.
adapted for additional balance/ffwd/rewind buttons
--------------------------------------------------------------------*/

#include </lib/std.mi>
#include </lib/pldir.mi>

Function setTempText(String txt);
Function emptyTempText();

Global Text Songticker;
Global Slider Volbar, Balbar, Seeker, SeekGhost,XFadebar;
Global Int Seeking;

Class GuiObject HintObject;
Class ToggleButton HintToggleButton;

Global HintObject Play, Stop, Previous, Next, Pause, Thinger, Open, Eq, Ml, Pl, Back,Forward;
Global HintToggleButton ToggleXFade, ToggleShuffle, ToggleRepeat;

System.onScriptUnloading() {
}

System.onScriptLoaded() {

  Group pgroup = getScriptGroup();

  // Get songticker, Volbar, Balbar & Seeker
  Songticker = pgroup.findObject("Songticker");
  if (songticker == null) messagebox("ooch!!", "ooch", 0, "");
  Volbar = pgroup.findObject("Volume");
  Balbar = pgroup.findObject("Balance");
  Seeker = pgroup.findObject("Seeker");
  SeekGhost = pgroup.findObject("SeekerGhost");
  // Get Various buttons
  Play = pgroup.findObject("Play");
  Pause = pgroup.findObject("Pause");
  Stop = pgroup.findObject("Stop");
  Next = pgroup.findObject("Next");
  Previous = pgroup.findObject("Previous");
  Forward = pgroup.findObject("5Forward");
  Back = pgroup.findObject("5Back");
  Thinger = pgroup.findObject("Thinger");
  Open = pgroup.findObject("Eject");

  Eq = pgroup.findObject("Eq");
  Ml = pgroup.findObject("Ml");
  Pl = pgroup.findObject("Pl");

  if (SeekGhost != NULL)
    SeekGhost.setAlpha(1);
}


Volbar.onSetPosition(int p) {
  Float f;
  f = p;
  f = f / 255 * 100;
  setTempText("Volume: " + System.integerToString(f) + "%");
}

Volbar.onSetFinalPosition(int p) {
  Songticker.setAlternateText("");
}

Balbar.onSetPosition(int p) {
  Float f;
  f = p;
  f = (f-127) / 127 * 100;
  if (p == 127) 
  setTempText("Balance: Center");
  else if (p >127)
  setTempText("Balance: " + System.integerToString(f) + "% right");
  else
  setTempText("Balance: " + System.integerToString(-f) + "% left");
}

Balbar.onSetFinalPosition(int p) {
  Songticker.setAlternateText("");
}

Seeker.onSetPosition(int p) {
  if (!SeekGhost && seeking) {
    Float f;
    f = p;
    f = f / 255 * 100;
    Float len = getPlayItemLength();
    if (len != 0) {
      int np = len * f / 100;
      setTempText("Seek to " + integerToTime(np) + " / " + integerToTime(len) + " (" + integerToString(f) + "%)");
    }
  }
}

Seeker.onLeftButtonDown(int x, int y) {
  seeking = 1;
}

Seeker.onLeftButtonUp(int x, int y) {
  seeking = 0;
  setTempText("");
}

Seeker.onRightButtonDown(int x, int y) {
  seeking = 0;
  setTempText("");
}


SeekGhost.onSetPosition(int p) {
  if (getalpha() == 1) return;
  Float f;
  f = p;
  f = f / 255 * 100;
  Float len = getPlayItemLength();
  if (len != 0) {
    int np = len * f / 100;
    setTempText("Seek to " + integerToTime(np) + " / " + integerToTime(len) + " (" + integerToString(f) + "%)");
  }
}

SeekGhost.onLeftButtonDown(int x, int y) {
  SeekGhost.setAlpha(128);
}

SeekGhost.onLeftButtonUp(int x, int y) {
  SeekGhost.setAlpha(1);
}

Seeker.onSetFinalPosition(int p) {
  Songticker.setAlternateText("");
}

SeekGhost.onsetfinalposition(int p) {
  Songticker.setAlternateText("");
  SeekGhost.setAlpha(1);
}

HintObject.onLeftButtonDown(int x, int y) {
  if (HintObject == Play) setTempText("Play");
  else if (HintObject == Stop) setTempText("Stop");
  else if (HintObject == Pause) setTempText("Pause");
  else if (HintObject == Next) setTempText("Next");
  else if (HintObject == Previous) setTempText("Previous");
/*
  else if (HintObject == Forward) setTempText("Fast forward 5 seconds");
  else if (HintObject == Back) setTempText("Rewind 5 seconds");
*/
  else if (HintObject == Thinger) setTempText("Thinger");
  else if (HintObject == Open) setTempText("Open");
  else if (HintObject == Eq) setTempText("Equalizer");
  else if (HintObject == ML) setTempText("Media Library");
  else if (HintObject == Pl) setTempText("Playlist Editor");
}

HintObject.onLeftButtonUp(int x, int y) {
  emptyTempText();
}

Thinger.onRightButtonUp(int x, int y) {
  windowMenu();
  complete;
}

setTempText(String txt) {
  Songticker.setAlternateText(txt);
}

emptyTempText() {
  Songticker.setAlternateText("");
}
