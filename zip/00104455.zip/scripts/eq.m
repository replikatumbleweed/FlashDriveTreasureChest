/*--------------------------------------------------------------------
 Main/Normal player group script.
adapted for additional balance/ffwd/rewind buttons
--------------------------------------------------------------------*/

#include </lib/std.mi>
#include </lib/pldir.mi>

Function setTempText(String txt);
Function emptyTempText();

Global Text Songticker;
Global Slider Volbar, Balbar, XFadebar;

System.onScriptUnloading() {
}

System.onScriptLoaded() {

  Group pgroup = getScriptGroup();
  Group plgroup = getGroup("main");

  // Get songticker, Volbar, Balbar & XFade
  Songticker = plgroup.findObject("Songticker");
  if (songticker == null) messagebox("eq no songticker", "ooch", 0, "");
  Volbar = pgroup.findObject("Volume");
  if (Volbar == null) messagebox("eq no Volbar", "ooch", 0, "");
  Balbar = pgroup.findObject("Balance");
  if (Balbar == null) messagebox("eq no Balbar", "ooch", 0, "");
  XFadebar = pgroup.findobject("sCrossfade");
  if (XFadebar == null) messagebox("eq no xfade", "ooch", 0, "");
}

XFadebar.onSetPosition(int p) {
  setTempText("Crossfade: " + System.integerToString(p) + " s");
}

XFadebar.onSetFinalPosition(int p) {
  Songticker.setAlternateText("");
}


Volbar.onSetPosition(int p) {
  Float f;
  f = p;
  f = f / 255 * 100;
  setTempText("Volume: " + System.integerToString(f) + "%");
}

Volbar.onSetFinalPosition(int p) {
  Songticker.setAlternateText("");
}

Balbar.onSetPosition(int p) {
  Float f;
  f = p;
  f = (f-127) / 127 * 100;
  if (p == 127) 
  setTempText("Balance: Center");
  else if (p >127)
  setTempText("Balance: " + System.integerToString(f) + "% right");
  else
  setTempText("Balance: " + System.integerToString(-f) + "% left");
}

Balbar.onSetFinalPosition(int p) {
  Songticker.setAlternateText("");
}

setTempText(String txt) {
  Songticker.setAlternateText(txt);
}

emptyTempText() {
  Songticker.setAlternateText("");
}
