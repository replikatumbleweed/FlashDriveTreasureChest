---
SCUAIR cc (a SCUAIR mo colorscheme)
WA 2.91 skin - by bunji
--
The eq-sliders and playlist-scroller were reworked for this version.
--

SCUAIR cc is my attempt on the metal-skin franchise. Hope you dig it! I put about 40 hours of work into this little baby.

Created with inspration from 883(883design.tk) and with help from Joe Petagno III - thanks for the words of wisdom. Id3tag font '@s and &s' ideas taken from 'master h - thirteen' album credits.

---
20-11-03 @ 00:00 by BUNJI DESIGN 2003
---
More skins @ geocities.com/bunjidesign
---