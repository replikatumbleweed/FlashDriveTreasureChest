//***************************************************
//
// Created by Thomas Michgelsen 2005
// Partially based on open source notifier
// by Jared Kole a.k.a. iPlayTheSpoons
//
// I changed the original drasticly to suit my needs.
//
//***************************************************


Function loadnotifier();
Function unloadnotifier();

Function setinfo();
Function setsize(float fadetime);
Function go();
Function nuke();

Global Layout popup, preferencestoggle, preferencessliders;
Global Text artist, song;
Global Togglebutton onoff, alwaysselector;
Global Slider fadetimeslider, holdtimeslider;
Global Boolean on, always, tracker;
Global Timer stay;
Global Float fadetime, holdtime;


Loadnotifier() {

	popup = getContainer("notifier.popup").getLayout("normal");
	preferencestoggle = getContainer("notifier.preferences").getLayout("toggle");
	preferencessliders = getContainer("notifier.preferences").getLayout("sliders");

	artist = popup.getObject("artist");
	song = popup.getObject("song");

	onoff = preferencestoggle.getObject("notifieronoff");
	alwaysselector = preferencestoggle.getObject("alwaysselector");
	fadetimeslider = preferencessliders.getObject("fadetime");
	holdtimeslider = preferencessliders.getObject("holdtime");

	stay = new timer;

	if(getPrivateInt("Rectangular", "on", 1)) {on = 1; onoff.setActivated(1);}
	if(!getPrivateInt("Rectangular", "on", 1)) {on = 0; onoff.setActivated(0);}

	if(getPrivateInt("Rectangular", "always", 1)) {always = 1; alwaysselector.setActivated(1);}
	if(!getPrivateInt("Rectangular", "always", 1)) {always = 0; alwaysselector.setActivated(0);}

	fadetime = getPrivateInt("Rectangular", "fadetime", 2);
	holdtime = getPrivateInt("Rectangular", "holdtime", 4);
	fadetimeslider.setPosition(fadetime);
	holdtimeslider.setPosition(holdtime);

	nuke();

}
Unloadnotifier() {
	delete stay;
	setPrivateInt("Rectangular", "on", on);
	setPrivateInt("Rectangular", "always", always);
	setPrivateInt("Rectangular", "holdtime", ((holdtime/1000)*2));
}


Onoff.onLeftButtonUp(int x, int y) {
	on = onoff.getActivated();
}
Alwaysselector.onLeftButtonUp(int x, int y) {
	always = alwaysselector.getActivated();
}


Fadetimeslider.onSetPosition(int newfadetime) {
	fadetime = (newfadetime/2);
	setPrivateInt("Rectangular", "fadetime", fadetime*2);
}

Holdtimeslider.onSetPosition(int newholdtime) {
	holdtime = ((newholdtime*1000)/2); 
	stay.setdelay(holdtime);
}


Popup.onLeftButtonUp(int x, int y) {nuke();}
Popup.onRightButtonUp(int x, int y) {nuke();}


System.onTitleChange(string newtitle) {
	if(strleft(getPlayItemString(), 7) == "http://") {nuke();}
	else go();
}
System.onPlay() {
	go();

	// Stereomonoindicator
	if(strsearch(getSongInfoText(), "mono") > -1) {stereomonotext.setText("mono");}
	else {stereomonotext.setText("stereo");}

	// Clock & Skinnameticker
	timerplayernormal.setText("");
	timerplayercompact.setText("");
	tickerplayernormal.setText("");
	tickerpleditcompact.setText("");	
}
System.onResume() {
	if(strleft(getPlayItemString(), 7) == "http://") {nuke();}
	else go();
}
System.onShowNotification() {
	if(strleft(getPlayItemString(), 7) == "http://") {nuke();}
	else go();
	return 1;
}


Nuke() {
	popup.hide();
	popup.setAlpha(0);
	popup.cancelTarget();
	stay.stop();
	tracker = 0;
	complete;
}


Go() {
	if(on) {
		if(!always && isMinimized()) {
			setinfo();
			setsize(fadetime);
		}
		if(always) {
			setinfo();
			setsize(fadetime);
		}
	}
	else return;
}


Setinfo() {
	artist.setText(getPlayItemMetaDataString("artist"));
	song.setText(getPlayItemMetaDataString("title"));
}

Setsize(float fadetime) {

	Int x = getViewportWidth();
	Int y = getViewportHeight();

	Int w = (artist.getAutoWidth());
	if(w < (song.getAutoWidth())) {w = (song.getAutoWidth());}
	w = w + 20;
	if(w > (x - 40)) {w = x - 40;}

	popup.resize(x-w-5, y-55, w, 50);

	tracker = 1;
	popup.show();
	popup.setTargetA(255);
	popup.setTargetX(x-w-5);
	popup.setTargetY(y-55);
	popup.setTargetW(w);
	popup.setTargetSpeed(fadetime);
	popup.gotoTarget();

}


Popup.onTargetReached() {
	if (tracker) {
		stay.stop();
		stay.start();
	}
	if (!tracker) {
		nuke();
	}
}
	
Stay.onTimer() {
	stay.stop();
	tracker = 0;
	popup.setTargetA(0);
	popup.setTargetSpeed(fadetime);
	popup.gotoTarget();
}