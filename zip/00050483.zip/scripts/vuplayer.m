#include <lib/std.mi>
#include <lib/config.mi>

#define OPTIONS_MENU "{1828D28F-78DD-4647-8532-EBA504B8FC04}"
#define CUSTOM_PAGE "{7438AC40-4D29-11DA-8CD6-0800200C9A66}"

Function loadvuplayer();
Function unloadvuplayer();

Global Layer statusleft, statusright;
Global AnimatedLayer vulayerleftnormal, vulayerrightnormal, vulayerleftcompact, vulayerrightcompact;
Global Double vuleftnormal, vurightnormal, vuleftcompact, vurightcompact;
Global Double oldleftnormal, oldrightnormal, oldleftcompact, oldrightcompact;
Global Double oneframenormal, oneframecompact;
Global Timer vutimer;
Global ConfigAttribute vumeteron;
Global Boolean on, dotmode;
Global Togglebutton bardotselector; 


Loadvuplayer() {

	statusleft = playernormal.getObject("statusleft");
	statusright = playernormal.getObject("statusright");
 
	vulayerleftnormal = playernormal.getObject("vulayerleft");
	vulayerrightnormal = playernormal.getObject("vulayerright");
	vulayerleftcompact = playercompact.getObject("vulayerleft");
	vulayerrightcompact = playercompact.getObject("vulayerright");

	bardotselector = playernormal.getObject("bardot");

	oneframenormal = 256/(vulayerleftnormal.getLength());
	oneframecompact = 256/(vulayerleftcompact.getLength());

	oldleftnormal = 0;
	oldrightnormal = 0;
	oldleftcompact = 0;
	oldrightcompact = 0;

	ConfigItem custom_page = Config.newItem(System.getSkinName(), CUSTOM_PAGE);
	ConfigItem custom_options_page = Config.getItem(OPTIONS_MENU);
	ConfigAttribute attsubmenu = custom_options_page.newAttribute(System.getSkinName(), "");
	attsubmenu.setData(CUSTOM_PAGE);
	vumeteron = custom_page.newAttribute("Enable Main VU Meters", "1");
	on = stringToInteger(vumeteron.getData());

	vutimer = new Timer;
	vutimer.setDelay(10);
	if(on) {vutimer.start();}

	if(on) {statusleft.setXmlParam("image", "led.play"); statusright.setXmlParam("image", "led.play");}
	else {statusleft.setXmlParam("image", "led.stop"); statusright.setXmlParam("image", "led.stop");}

	vulayerleftnormal.setSpeed(10);
	vulayerrightnormal.setSpeed(10);
	vulayerleftcompact.setSpeed(10);
	vulayerrightcompact.setSpeed(10);

	if(getPrivateInt("Rectangular", "vumodeplayer", 0)) {
		dotmode = 1;
		bardotselector.setActivated(1);
		vulayerleftnormal.setXmlParam("image", "frames.vu.player.dot");
		vulayerrightnormal.setXmlParam("image", "frames.vu.player.dot");
	}
	if(!getPrivateInt("Rectangular", "vumodeplayer", 0)) {
		dotmode = 0;
		bardotselector.setActivated(0);
		vulayerleftnormal.setXmlParam("image", "frames.vu.player.bar");
		vulayerrightnormal.setXmlParam("image", "frames.vu.player.bar");		
	}
}
Unloadvuplayer() {
	delete vutimer;
	setPrivateInt("Rectangular", "vumodeplayer", dotmode);
}


Vutimer.onTimer() {

	vuleftnormal = getLeftVuMeter();
	vurightnormal = getRightVuMeter();
	vuleftcompact = vuleftnormal;
	vurightcompact = vurightnormal;

	if(vuleftnormal < oldleftnormal) {vuleftnormal = (oldleftnormal - oneframenormal);}
	if(vuleftnormal < 0) {vuleftnormal = 0;}
	oldleftnormal = vuleftnormal;

	if(vurightnormal < oldrightnormal) {vurightnormal = (oldrightnormal - oneframenormal);}
	if(vurightnormal < 0) {vurightnormal = 0;}
	oldrightnormal = vurightnormal;

	if(vuleftcompact < oldleftcompact) {vuleftcompact = (oldleftcompact - (0.5 * oneframecompact));}
	if(vuleftcompact < 0) {vuleftcompact = 0;}
	oldleftcompact = vuleftcompact;

	if(vurightcompact < oldrightcompact) {vurightcompact = (oldrightcompact - (0.5 * oneframecompact));}
	if(vurightcompact < 0) {vurightcompact = 0;}
	oldrightcompact = vurightcompact;

	vulayerleftnormal.goToFrame(vuleftnormal / oneframenormal);
	vulayerrightnormal.goToFrame(vurightnormal / oneframenormal);
	vulayerleftcompact.goToFrame(vuleftcompact / oneframecompact);
	vulayerrightcompact.goToFrame(vurightcompact / oneframecompact);

}


Bardotselector.onLeftButtonUp(int x, int y) {
	dotmode = bardotselector.getActivated();
	if(!dotmode) {
		vulayerleftnormal.setXmlParam("image", "frames.vu.player.bar");
		vulayerrightnormal.setXmlParam("image", "frames.vu.player.bar");
	}
	if(dotmode) {
		vulayerleftnormal.setXmlParam("image", "frames.vu.player.dot");
		vulayerrightnormal.setXmlParam("image", "frames.vu.player.dot");
	}
}


Statusleft.onLeftButtonUp(int x, int y) {
	if(on) {vumeteron.setData("0"); statusleft.setXmlParam("image", "led.stop"); statusright.setXmlParam("image", "led.stop");}
	else {vumeteron.setData("1"); statusleft.setXmlParam("image", "led.play"); statusright.setXmlParam("image", "led.play");}
}
Statusright.onLeftButtonUp(int x, int y) {
	if(on) {vumeteron.setData("0"); statusleft.setXmlParam("image", "led.stop"); statusright.setXmlParam("image", "led.stop");}
	else {vumeteron.setData("1"); statusleft.setXmlParam("image", "led.play"); statusright.setXmlParam("image", "led.play");}
}

Vumeteron.onDataChanged() {

	on = stringToInteger(vumeteron.getData());

	if(!on) {
		vutimer.stop();

		vulayerleftnormal.stop();
		vulayerrightnormal.stop();
		vulayerleftcompact.stop();
		vulayerrightcompact.stop();

		vulayerleftnormal.goToFrame(0);
		vulayerrightnormal.goToFrame(0);
		vulayerleftcompact.goToFrame(0);
		vulayerrightcompact.goToFrame(0);

		statusleft.setXmlParam("image", "led.stop");
		statusright.setXmlParam("image", "led.stop");
	}
	else {
		vutimer.start();

		statusleft.setXmlParam("image", "led.play");
		statusright.setXmlParam("image", "led.play");
	}	
}