#include <lib/std.mi>
#include <lib/config.mi>

#include "detective.m"
#include "text.m"
#include "vuplayer.m"
#include "vumonitor.m"
#include "notifier.m"


System.onScriptLoaded() {

	loaddetective();
	loadtext();
	loadvuplayer();
	loadvumonitor();
	loadnotifier();

}


System.onScriptUnloading() {

	unloadtext();
	unloadvuplayer();
	unloadvumonitor();
	unloadnotifier();

}