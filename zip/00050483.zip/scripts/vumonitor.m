Function loadvumonitor();
Function unloadvumonitor();

Global Layout vuled, vuanalog;
Global AnimatedLayer vulayerleftled, vulayerrightled, vulayerleftanalog, vulayerrightanalog;
Global Double vuleftled, vurightled, vuleftanalog, vurightanalog;
Global Double oldleftled, oldrightled, oldleftanalog, oldrightanalog;
Global Double oneframeled, oneframeanalog;
Global Timer vutimer;
Global Boolean dotmode;
Global Togglebutton bardotselector;


Loadvumonitor() {

	vuled = getContainer("vu").getLayout("led");
	vuanalog = getContainer("vu").getLayout("analog");

	vulayerleftled = vuled.getObject("vulayerleft");
	vulayerrightled = vuled.getObject("vulayerright");
	vulayerleftanalog = vuanalog.getObject("vulayerleft");
	vulayerrightanalog = vuanalog.getObject("vulayerright");

	bardotselector = vuled.getObject("bardot");

	oneframeled = 256/(vulayerleftled.getLength());
	oneframeanalog = 256/(vulayerleftanalog.getLength());

	oldleftled = 0;
	oldrightled = 0;
	oldleftanalog = 0;
	oldrightanalog = 0;

	vutimer = new Timer;
	vutimer.setDelay(10);
	vutimer.start();

	vulayerleftled.setSpeed(10);
	vulayerrightled.setSpeed(10);
	vulayerleftanalog.setSpeed(10);
	vulayerrightanalog.setSpeed(10);

	if(getPrivateInt("Rectangular", "vumodemonitor", 0)) {
		dotmode = 1;
		bardotselector.setActivated(1);
		vulayerleftled.setXmlParam("image", "frames.vu.monitor.dot");
		vulayerrightled.setXmlParam("image", "frames.vu.monitor.dot");
	}
	if(!getPrivateInt("Rectangular", "vumodemonitor", 0)) {
		dotmode = 0;
		bardotselector.setActivated(0);
		vulayerleftled.setXmlParam("image", "frames.vu.monitor.bar");
		vulayerrightled.setXmlParam("image", "frames.vu.monitor.bar");		
	}

}
Unloadvumonitor() {
	delete vutimer;
	setPrivateInt("Rectangular", "vumodemonitor", dotmode);
}


Vutimer.onTimer() {

	vuleftled = getLeftVuMeter();
	vurightled = getRightVuMeter();
	vuleftanalog = vuleftled;
	vurightanalog = vurightled;

	if(vuleftled < oldleftled) {vuleftled = (oldleftled - oneframeled);}
	if(vuleftled < 0) {vuleftled = 0;}
	oldleftled = vuleftled;

	if(vurightled < oldrightled) {vurightled = (oldrightled - oneframeled);}
	if(vurightled < 0) {vurightled = 0;}
	oldrightled = vurightled;

	if(vuleftanalog < oldleftanalog) {vuleftanalog = (oldleftanalog - oneframeanalog);}
	if(vuleftanalog < 0) {vuleftanalog = 0;}
	oldleftanalog = vuleftanalog;

	if(vurightanalog < oldrightanalog) {vurightanalog = (oldrightanalog - oneframeanalog);}
	if(vurightanalog < 0) {vurightanalog = 0;}
	oldrightanalog = vurightanalog;

	vulayerleftled.goToFrame(vuleftled / oneframeled);
	vulayerrightled.goToFrame(vurightled / oneframeled);
	vulayerleftanalog.goToFrame(vuleftanalog / oneframeanalog);
	vulayerrightanalog.goToFrame(vurightanalog / oneframeanalog);

}


Bardotselector.onLeftButtonUp(int x, int y) {
	dotmode = bardotselector.getActivated();
	if(!dotmode) {
		vulayerleftled.setXmlParam("image", "frames.vu.monitor.bar");
		vulayerrightled.setXmlParam("image", "frames.vu.monitor.bar");
	}
	if(dotmode) {
		vulayerleftled.setXmlParam("image", "frames.vu.monitor.dot");
		vulayerrightled.setXmlParam("image", "frames.vu.monitor.dot");
	}
}