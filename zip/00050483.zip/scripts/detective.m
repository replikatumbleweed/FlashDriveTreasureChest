Function loaddetective();

Global Layout playernormal, playercompact, eqcompact, pleditcompact;
Global Text timerplayernormal, timerplayercompact, tickerplayernormal, tickerpleditcompact, stereomonotext;
Global String skinname;


Loaddetective() {

	playernormal = getContainer("main").getLayout("normal");
	playercompact = getContainer("main").getLayout("compact");
	eqcompact = getContainer("eq").getLayout("compact");
	pleditcompact = getContainer("pledit").getLayout("compact");

	timerplayernormal = playernormal.getObject("timer");
	timerplayercompact = playercompact.getObject("timer");
	tickerplayernormal = playernormal.getObject("songticker");
	tickerpleditcompact = pleditcompact.getObject("songticker");
	stereomonotext = playernormal.getObject("stereo.mono.indicator");

	skinname = getSkinName();

}