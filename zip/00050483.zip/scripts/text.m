//************************************
//
// Created by Thomas Michgelsen 2005
//
// Handles all text functions, such as
// seeker, volume, skinname, clock and
// stereo/mono.
//
//************************************


Function loadtext();
Function unloadtext();
Function settickertext(int p);
Function erasetickertext();

Global Slider volumenormal, seekernormal, volumecompact, seekercompact;
Global Timer tickertimer, clocktimer;


Loadtext() {

	volumenormal = playernormal.getObject("volume");
	seekernormal = playernormal.getObject("seeker");
	volumecompact = eqcompact.getObject("volume");
	seekercompact = eqcompact.getObject("seeker");

	tickertimer = new timer;
	tickertimer.setDelay(1000);

	clocktimer = new timer;
	clocktimer.setDelay(1000);

	if(getStatus() == 0) {
		string timestring = integerToLongTime(getTimeOfDay());
		timestring = strleft(timestring, strlen(timestring)-3);
		timerplayernormal.setText(timestring);
		timerplayercompact.setText(timestring);
		clocktimer.start();
		tickerplayernormal.setText(skinname);
		tickerpleditcompact.setText(skinname);
	}
	else if(strsearch(getSongInfoText(), "mono") > -1) {stereomonotext.setText("mono");}
	else {stereomonotext.setText("stereo");}

}
Unloadtext() {
	delete tickertimer;
	delete clocktimer;
}


Clocktimer.onTimer() {
	if(getStatus() == 0) {
		string timestring = integerToLongTime(getTimeOfDay());
		timestring = strleft(timestring, strlen(timestring)-3);
		timerplayernormal.setText(timestring);
		timerplayercompact.setText(timestring);
	}
	else clocktimer.stop();
}
System.onStop() {
	clocktimer.start();
	string timestring = integerToLongTime(getTimeOfDay());
	timestring = strleft(timestring, strlen(timestring)-3);
	timerplayernormal.setText(timestring);
	timerplayercompact.setText(timestring);
	tickerplayernormal.setText(skinname); 
	tickerpleditcompact.setText(skinname);
	stereomonotext.setText("");
}


Seekernormal.onSetPosition(int p) {
	settickertext(p);
}
Seekernormal.onSetFinalPosition(int p) {
	erasetickertext();
}
Seekercompact.onSetPosition(int p) {
	settickertext(p);
}
Seekercompact.onSetFinalPosition(int p) {
	erasetickertext();
}


Settickertext(int p) {

	tickertimer.stop();
	tickertimer.start();

	float s;
	s = p;
	s = s / 255 * 100;
	int length = getPlayItemLength();
	int currentposition = length * s / 100;

	if(strsearch(timerplayernormal.getText(), "-") > -1) {
		tickerplayernormal.setText("Seeker: -" + integerToTime(length - currentposition) + " / " + integerToTime(length) + " (" + integerToString(s) + "%)");
		tickerpleditcompact.setText("Seeker: -" + integerToTime(length - currentposition) + " / " + integerToTime(length) + " (" + integerToString(s) + "%)");
	}
	else {
		tickerplayernormal.setText("Seeker: " + integerToTime(currentposition) + " / " + integerToTime(length) + " (" + integerToString(s) + "%)");
		tickerpleditcompact.setText("Seeker: " + integerToTime(currentposition) + " / " + integerToTime(length) + " (" + integerToString(s) + "%)");
	}
}

Erasetickertext() {
	tickertimer.stop();
	if(getStatus() == 0) {
		tickerplayernormal.setText(skinname); 
		tickerpleditcompact.setText(skinname);
	} else {
		tickerplayernormal.setText("");
		tickerpleditcompact.setText("");
	}
}
Tickertimer.onTimer() {
	erasetickertext();
}


System.onVolumeChanged(int v) {
	tickertimer.stop();
	tickertimer.start();
	tickerplayernormal.setText("Volume: " + integerToString(v * 100 / 255) + "%");
	tickerpleditcompact.setText("Volume: " + integerToString(v * 100 / 255) + "%");
}
Volumenormal.onSetFinalPosition(int v) {
	erasetickertext();
}
Volumecompact.onSetFinalPosition(int v) {
	erasetickertext();
}


System.onInfoChange(string info) {
	if(getStatus() != 0) {
		if(strsearch(info, "mono") > -1) {stereomonotext.setText("mono");}
		else {stereomonotext.setText("stereo");}
	}
}