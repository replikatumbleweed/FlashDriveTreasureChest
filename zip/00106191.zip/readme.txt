-============== WinSkin 2.9 ==============-
 -=====================================-

        Winamp skin for Winamp v2.9 or lower.

Skin para Winamp v2.9 ou vers�es anteriores (deve funcionar com vers�es posteriores tamb�m), baseado no desenho do Windows 98/2000.

Fernando Silveira
-----------------------------
fernandopsilveira@hotmail.com

P.S.: no arquivo est� inclu�da uma vers�o experimental do arquivo genex.bmp, com as cores padr�o do Win98.