Remote Speakers Output Plug-In
Stream audio from MediaMonkey, Winamp or XMPlay to the AirPort Express, Apple TV
  and other AirPlay/AirTunes-compatible devices

Copyright (c) 2006-2011  Eric Milles

http://emilles.dyndns.org/software/out_apx.html



REQUIREMENTS
------------
1) AirPort Express by Apple (http://www.apple.com/airportexpress/)
     or
   Apple TV by Apple (http://www.apple.com/appletv/)
     or
   Other AirPlay/AirTunes-compatibile device or software

2) MediaMonkey by Ventis Media (http://www.mediamonkey.com/)
     or
   Winamp by Nullsoft (http://www.winamp.com/)
     or
   XMPlay by Un4seen Developments (http://www.xmplay.com/)

3) Express Remote by Keyspan (http://www.tripplite.com/en/products/Discontinued-Products.cfm?MDLID=3911)
     (necessary only for remote control)



INSTALLATION
------------
1) Close player and uninstall any previous version(s) of the plug-in.

2) Run the Bonjour installer (bonjour.msi).  Bonjour is highly recommended but
   not required.  It is used for automatic discovery of remote speakers devices.
   Bonjour 3.0 is included; check Apple website for updated versions
   (http://support.apple.com/downloads/Bonjour_for_Windows).

3) Run the Remote Speakers Outupt Plug-In installer (rsoutput.msi).

4) For MediaMonkey or Winamp: Copy out_apx.dll from plug-in install location --
   usually C:\Program Files\Common Files\Remote Speakers output -- to player's
   Plugins directory.

   For XMPlay: Copy xmp-apx.dll from from plug-in install location -- usually
   C:\Program Files\Common Files\Remote Speakers output -- to player's directory.

5) If using Bonjour or Remote Control, open the following ports on your firewall
   for incoming traffic:
    * 3689/TCP (necessary for remote control)
    * 5353/UDP (necessary for discovery of remote speakers)



CONFIGURATION
-------------
Open player options dialog and select Output Plug-ins.  Select Remote Speakers
output from the list of output plug-ins.  Click Configure.  There are three
options that can be configured for the plug-in in addition to selecting the
desired remote speakers:

1) Remote speakers - list of remote speakers on local subnet.  If using Bonjour,
   this list updates automatically as remote speakers come and go.  Right-click
   inside the listbox to add or edit static entries.

2) Allow player to control volume of remote speakers - if checked, player's
   volume bar (or knob depending on your choice of skin) will influence the
   playback volume of the remote speakers.  If unchecked, the AirPort Express
   will playback audio at full volume.

3) Allow player to be controlled by remote speakers - if checked, Express Remote
   may be used to control playback from remote speakers location.  If unchecked,
   Express Remote functionality is disabled and port 3689 is unused.

4) Clear playback buffer of remote speakers on pause - if checked, the plug-in
   will instruct the remote speakers to flush its playback buffer on pause.  This
   causes playback to stop more quickly but causes some clipping of the track
   when playback is resumed.  If unchecked, no flush command will be sent so
   playback will take a few seconds to halt but there will not be any clipping
   of the track if playback is resumed.



REGISTRATION
------------
Visit the plug-in's main page (http://emilles.dyndns.org/software/out_apx.html)
with your site code to purchase a license and receive an activation code.

If you have already purchased a license and are experiencing problems or need to
setup on a new workstation, send me an email (registration@emilles.dyndns.org).



KNOWN ISSUES
------------
1) Certain versions of MediaMonkey -- including 3.2.2 -- have an issue with
   plug-ins that display a modal dialog box during startup. A modal dialog
   prevents any actions from occurring in any other windows of the application
   until it is dismissed. But in this case, the dialog box is not visible (only
   the MM splash screen is). So no action can be taken to break the deadlock.

   Starting MediaMonkey with the NoSplash option works around the issue. To start
   MediaMonkey this way, edit the shorcut that is used to start it by adding
   /NoSplash to the end of the shortcut's Target property. Right-click on the
   shortcut and select Properties from the context menu to edit the Target. So,
   for example, the shortcut target may be something like:
   "C:\Program Files\MediaMonkey\MediaMonkey.exe" /NoSplash. You can also try
   this in the Start > Run... dialog to see if it corrects the problem before
   modifying your shortcut(s).

2) MediaMonkey and Winamp's default behavior when an output plug-in is unable to
   play a track is to move on to the next track and try to play it.  This isn't
   so good from the user's perspective when the plug-in is unable to connect to
   the selected remote speakers.  Connect dialogs keep popping up over and over
   as tracks in the playlist are advanced through by the player.

3) Playback timer is hurried when the remote speakers playback buffer is being
   filled.  This could be fixed if I was able to correctly determine the
   current latency of the AirPort Express.  Maybe someday this will be fixed.



QUESTIONS AND COMMENTS
----------------------
Visit the plug-in's FAQ page (http://emilles.dyndns.org/software/out_apx/faq.html)
first to see if your question or comment has already been answered.

I encourage you to report any problems you find with the plug-in or suggest any
features you would like to see added in future versions.  Send me an email
(support@emilles.dyndns.org).  For problem reports, include the error message and
error code you receive, the version of the player and Windows you are running
with and the firmware version of your AirPort Express (if you know it) along with
a complete description of what you were doing when the error occurred.
