WELCOME TO YOUR DOOM!
I have no connection to the people who own and make the Homestar cartoons and website. The characters and situations depicted in this skin, as well as virtually all of the original graphics, were created by Mike and Matt Chapman. That being said, their website, WWW.HOMESTARRUNNER.COM is very, very awesome and hilarious. 
You can find the inspiration of this Winamp skin in the Strong Bad Emails (sb emails) section of the web site. This skin is based of of Strong Bad's first computer, which Strong Bad used to answer every email up to and including the email "Gimmicks."
If you like this skin, you might also like my other skins! Check out my profile here:
http://www.1001winampskins.com/member_profile.html?author_id=15239
I have made a Teen Girl Squad skin and also a Compy 386 skin based on the Homestar Runner website, as well as a lot of skins based on old video games.
This skin was made for thenostalgia contest on the Classic Skins forum at Winamp.com, in which it placed 2nd. See the results here: 
http://www.poppedarts.com/nostalgiacontest/index.htm
Made almost entirely in photoshop.
LuigiHann
AIM: LuigiHan
Email: LuigiHann@hotmail.com