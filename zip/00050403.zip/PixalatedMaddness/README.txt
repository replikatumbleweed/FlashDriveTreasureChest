***********************************************
         Pixelated Maddness v1.0
***********************************************
This skin covers the Main Player, The Playlist, The Equalizer, The Video, The General Windows, (Media Library, etc) all windowshades and MikroAmp

Info:

firstly thank you for downloading my skin and I hope that you enjoy it.

I have made this skin as part of a small competition on the WA forums, But have really enjoyed making it and may make future versions of this skin! if you find any bugs please let me know!

Riksruin (riksruin@alternativestyles.co.uk)
www.alternative styles.co.uk

If you have any comments on this skin or any other skin from my 
site then please E-mail Me using the address above.

