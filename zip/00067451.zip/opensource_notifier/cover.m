#include "../../../lib/std.mi"

Function UpdateCDCover();
Function String GetSkinPath(String strRaw);

Global Browser objBrowser;
Global String strSkinHTMLPath;

System.onScriptLoaded() {
	Group notifier = system.getScriptGroup();
	objBrowser = notifier.findObject("browser.cdcover");
	strSkinHTMLPath = System.getPath(objBrowser.getXMLParam("url"));
	if (System.getPlayItemString() != "") UpdateCDCover();
}

System.onTitleChange(String strNewTitle) {
	UpdateCDCover();
}

UpdateCDCover() {
	String strQuery = "";
	String strArtist = System.getPlayitemMetaDataString("artist");
	String strAlbum = System.getPlayitemMetaDataString("album");
	
	if (strArtist != "") strQuery += strArtist + " ";
	if (strAlbum != "") strQuery += strAlbum;

	objBrowser.navigateURL(strSkinHTMLPath + "\cdcover.html?" + System.urlEncode(strQuery));
}