"OpenSource" Notifier - by Jared Kole (iplaythespoons@hotmail.com)

How to use:

1)  Add the opensource_notifier folder to your skin's directory
2)  Add "<include file="opensource_notifier/notifier.xml" />" to your skin.xml

You may notice the prefrences window added to the right click menu.  It can be removed from the right click menu by changing the nomenu= param in the notifier's container.  It should be pretty easy with some knowledge of maki to move those prefrences to sliders within the skin.  If you need help, email me any time.

massive thanks to RPeterClark for the album view script

*****************
ATTENTION:
// MODDED FOR STAR TREK LCARS AMP PADD II by Jason Chiu
// Lost its modularity -- sorry guys :(
// Please download Metaskins.net & iPlayTheSpoons' "LayerOne" skin for the original and PORTABLE opensource_notifier
Thank you and sorry for the inconvenience.
*****************