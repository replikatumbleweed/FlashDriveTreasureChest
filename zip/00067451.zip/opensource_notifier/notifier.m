//-----------------------------------------------------------------------------
// notifier.m
//
// Add a Winamp Modern-esque notifier to your skin, with prefrences and all that
//
// by iPlayTheSpoons (Jared Kole)
//
// please leave this part when you distribute your skin
//-----------------------------------------------------------------------------
// MODDED FOR STAR TREK LCARS AMP PADD II by Jason Chiu
// Lost its modularity -- sorry
// Please download iPlayTheSpoons' "LayerOne" skin for the original and PORTABLE opensource_notifier
// [WA5.05 security update] Show Album cover no longer works
// removed redundant shadow opacity

#include <lib/std.mi>
#include "attribs.m"

Function Go(Float Fadein,Float Fadeout);
function SetSize();
Function SetInfo();
Function Prep();

Global Container Noti, Prefs;
Global Layout Notifier,NotifierSize;
Global Group Texts;
Global Text Artist, Song, Album, PlEntry, Nexttrack;
Global Text FadeinText,StayText,FadeoutText, FadeinText_c,StayText_c,FadeoutText_c;
Global Slider FadeinSlider, StaySlider, FadeoutSlider;//, ShadowSlider;
Global CheckBox FadeEffect, SlideEffect, Fullscreen, CDCover;

Global CheckBox ShowAlways, ShowMinimized, ShowNever;

//Global GUIObject Shadow;
//Global Browser PhysicalCover;
Global Timer Stay, Buffer;
Global Int Tracker, /*ShadowOpacity,*/ TitleW, Wide;
Global Float Fadein, Fadeout, StayTime;
Global String Effect, Position, Freq;

System.onScriptLoaded() { 
	initAttribs();

	Noti = system.getContainer("opensource_notifier");
	Notifier = Noti.getLayout("normal");
	NotifierSize = Noti.getLayout("normal");

	//PhysicalCover = Notifier.findObject("browser.cdcover");
	Texts = Notifier.findObject("notifier.text");

	Artist = Notifier.findObject("artist");
	Song = Notifier.findObject("title");
	Album = Notifier.findObject("album");
	PlEntry = Notifier.findObject("plentry");
	//Shadow = Notifier.findObject("shadow");


	//Prefs = system.getContainer("opensource_notifier_prefs");
	Prefs = system.getContainer("main");
	Layout PrefsLayout = Prefs.getLayout("normal");
	Layout PrefsLayout_c = Prefs.getLayout("compact");

	FadeinText = PrefsLayout.findObject("fadein.text");
	StayText = PrefsLayout.findObject("stay.text");
	FadeoutText = PrefsLayout.findObject("fadeout.text");

	FadeinText_c = PrefsLayout_c.findObject("fadein.text");
	StayText_c = PrefsLayout_c.findObject("stay.text");
	FadeoutText_c = PrefsLayout_c.findObject("fadeout.text");

	//FadeinSlider = PrefsLayout.findObject("fadein.slider");
	//StaySlider = PrefsLayout.findObject("stay.slider");
	//FadeoutSlider = PrefsLayout.findObject("fadeout.slider");
	//ShadowSlider = PrefsLayout.findObject("shadow.slider");

	//Fullscreen = PrefsLayout.findObject("fullscreen");
	//FadeEffect = PrefsLayout.findObject("radio.fade");
	//SlideEffect = PrefsLayout.findObject("radio.slide");
	//CDCover = PrefsLayout.findObject("cover");

	//added by JC
	/*ShowAlways = PrefsLayout.findObject("radio.show.always");
	ShowMinimized = PrefsLayout.findObject("radio.show.minimized");
	ShowNever = PrefsLayout.findObject("radio.show.never");*/

	//Fadein = system.getPrivateInt("OpenNote","FadeIn",6);
	//Fadeout = system.getPrivateInt("OpenNote","FadeOut",2);
	//StayTime = system.getPrivateInt("OpenNote","Stay",16);
	//ShadowOpacity = system.getPrivateInt("OpenNote","Shadow",255);
	//Effect = system.getPrivateString("OpenNote","Effect","Fade");

	/*if(Effect == "Fade")
		FadeEffect.setChecked(1);
	Else
		SlideEffect.setChecked(1);*/

	if(myattr_notifierFadeEffect.getData() == "1") Effect = "Fade";
	else if(myattr_notifierSlideEffect.getData() == "1") Effect = "Slide";

	//added by JC
	/*Freq = system.getPrivateString("OpenNote","Freq","Always Show Notifications");
	if (Freq == "Always Show Notifications") ShowAlways.setChecked(1);
	else if (Freq == "Show Notifications When Minimized") ShowMinimized.setChecked(1);
	else ShowNever.setChecked(1);*/

	Stay = new Timer;
	Buffer = new Timer;
	Buffer.setDelay(100);
	
	//FadeinSlider.SetPosition(Fadein);
	//FadeoutSlider.SetPosition(Fadeout);
	//StaySlider.SetPosition(StayTime);
	//ShadowSlider.setPosition(ShadowOpacity);

	myattr_notifierFadeInTime.onDataChanged();
	myattr_notifierHoldTime.onDataChanged();
	myattr_notifierFadeOutTime.onDataChanged();
	//myattr_notifierShadowOpacity.onDataChanged();

	//Fullscreen.setChecked(system.getPrivateInt("OpenNote","Fullscreen",0));
	//CDCover.setChecked(system.getPrivateInt("OpenNote","Cover",0));

	Notifier.hide();

	SetSize();
}

system.onScriptUnloading()
{
	//system.setPrivateInt("OpenNote","FadeIn",(Fadein*4));
	//system.setPrivateInt("OpenNote","FadeOut",(Fadeout*4));
	//system.setPrivateInt("OpenNote","Stay",((StayTime*4)/1000));
	//system.setPrivateInt("OpenNote","Shadow",ShadowOpacity);
	//system.setPrivateString("OpenNote","Effect",Effect);

	//system.setPrivateString("OpenNote","Freq",Freq);//added

	//system.setPrivateInt("OpenNote","Cover",CDCover.isChecked());
}

//added by JC
/*ShowAlways.onToggle(int newstate) {
	if (ShowAlways.isChecked() == 1) {
		Freq = "Always Show Notifications";
		system.setPrivateString("OpenNote","Freq",Freq);
	}
}
ShowMinimized.onToggle(int newstate) {
	if (ShowMinimized.isChecked() == 1) {
		Freq = "Show Notifications When Minimized";
		system.setPrivateString("OpenNote","Freq",Freq);
	}
}
ShowNever.onToggle(int newstate) {
	if (ShowNever.isChecked() == 1) {
		Freq = "Never Show Notifications";
		system.setPrivateString("OpenNote","Freq",Freq);
	}
}*/


/*Fullscreen.onToggle(int newstate) {
	system.setPrivateInt("OpenNote","Fullscreen",newstate);
}*/

//FadeEffect.onToggle(int newstate) {
myattr_notifierFadeEffect.onDataChanged() {
	//if(FadeEffect.isChecked() == 1) {
	if (myattr_notifierFadeEffect.getData() == "1") {
		Effect = "Fade";
		//FadeinSlider.SetPosition(Fadein*4);
		//FadeoutSlider.SetPosition(Fadeout*4);
		//StaySlider.setPosition((StayTime*4)/1000);
		myattr_notifierFadeInTime.onDataChanged();
		myattr_notifierFadeOutTime.onDataChanged();
	}
}

//SlideEffect.onToggle(int newstate) {
myattr_notifierSlideEffect.onDataChanged() {
	//if(SlideEffect.isChecked() == 1) {
	if (myattr_notifierSlideEffect.getData() == "1") {
		Effect = "Slide";
		//FadeinSlider.SetPosition(Fadein*4);
		//FadeoutSlider.SetPosition(Fadeout*4);
		//StaySlider.setPosition((StayTime*4)/1000);
		myattr_notifierFadeInTime.setData(myattr_notifierFadeInTime.getData());
		myattr_notifierFadeOutTime.setData(myattr_notifierFadeOutTime.getData());
		if(Tracker == 2) 	Notifier.setXMLParam("y",integertostring(system.getViewportHeight()+5));
	}
}

//ShadowSlider.onSetPosition(int newShadow) {
/*myattr_notifierShadowOpacity.onDataChanged() {
	//Shadow.setAlpha(newShadow);
	//ShadowOpacity = newShadow;
	ShadowOpacity = StringToInteger(myattr_notifierShadowOpacity.getData());
	Shadow.setAlpha(ShadowOpacity);
}*/

//FadeinSlider.onSetPosition(int newFadein) {
myattr_notifierFadeInTime.onDataChanged() {
	//FadeinText.setText(Effect+"-in Time (" + system.floattostring(NewFadein/4,1) + "s):");
	//Fadein=NewFadein/4;
	Fadein = StringToInteger(myattr_notifierFadeInTime.getData()) / 1000;
	FadeinText.setText(Effect + "-in Time (" + system.floattostring(Fadein, 1) + "s)");
	FadeinText_c.setText(Effect + "-in Time (" + system.floattostring(Fadein, 1) + "s)");
}

//FadeoutSlider.onSetPosition(int newFadeout) {
myattr_notifierFadeOutTime.onDataChanged() {
	//FadeoutText.setText(Effect+"-out Time (" + system.floattostring(NewFadeout/4,1) + "s):");
	//Fadeout=NewFadeout/4;
	Fadeout = StringToInteger(myattr_notifierFadeOutTime.getData()) / 1000;
	FadeoutText.setText(Effect + "-out Time (" + system.floattostring(Fadeout, 1) + "s)");
	FadeoutText_c.setText(Effect + "-out Time (" + system.floattostring(Fadeout, 1) + "s)");
}

//StaySlider.onSetPosition(int newStay) {
myattr_notifierHoldTime.onDataChanged() {
	//StayText.setText("Hold Time (" + system.floattostring(NewStay/4,1) + "s):");
	//StayTime = (newStay/4)*1000; 
	//Stay.setdelay(StayTime);
	StayTime = StringToInteger(myattr_notifierHoldTime.getData());
	StayText.setText("Hold Time (" + system.floattostring(StayTime / 1000, 1) + "s)");
	StayText_c.setText("Hold Time (" + system.floattostring(StayTime / 1000, 1) + "s)");
	Stay.setdelay(StayTime);
}



system.onTitleChange(String NewTitle) {
	Buffer.start();
}

system.onPlay() {
	Buffer.start();
}

system.onResume() {
	Buffer.start();
}

System.onShowNotification() {
	Buffer.start();
	complete;
  	return 1;
}

Buffer.onTimer() {
	Buffer.stop();
	prep();
}

Notifier.onLeftButtonDown(int x, int y) {
	Prefs.show();
}

Notifier.onRightButtonDown(int x, int y) {
	Notifier.hide();
}

Prep() {
	//string freq = system.getPrivateString("OpenNote","Freq","Always Show Notifications");
	//if((Fullscreen.isChecked() == 1 && System.isVideoFullscreen() == 0) || Fullscreen.isChecked() == 0) {
	if((myattr_notifierDisableFullscreen.getData() == "1" && System.isVideoFullscreen() == 0) || myattr_notifierDisableFullscreen.getData() == "0") {
		//if (freq=="Always Show Notifications") {
		if (myattr_notifierAlways.getData() == "1") {
			SetInfo();
			SetSize();
			Go(Fadein, FadeOut);
		} else {
			//if (freq=="Show Notifications When Minimized" && System.isMinimized()==1){
			if (myattr_notifierMinimized.getData() == "1" && System.isMinimized() == 1) {
				SetInfo();
				SetSize();
				Go(Fadein, FadeOut);
			} else {
				if (myattr_notifierWindowshade.getData() == "1" || System.isMinimized()) {
					Container c = getContainer("main");
					Layout l = c.getCurLayout();
					if (!l) return;
					if (l.getId() == "shade") {
						SetInfo();
						SetSize();
						Go(Fadein, FadeOut);
					}
				}
			}
		}
	}
}


SetInfo() {	
	Int stream = 0;
	if (StrLeft(getPlayItemString(), 7) == "http://") stream = 1;
	
	String PLTot = integertostring(System.getPlaylistLength());
	String PLCur = integertostring(System.getPlaylistIndex()+1);
	
	if(!stream){
		Int T = System.getPlayItemLength()/1000;
		Int M = T/60;
		Int S = T-(M*60);
		String Ss;
		if (S<10) {
			Ss = "0" + integertoString(S);
		}
		else {
			Ss = integertoString(S);
		}
		
		
		String name;
		if(getPlayItemMetaDataString("title")=="") {name="???";}
		else {name=System.getPlayItemMetaDataString("title");}
		
		Song.setXmlParam("ticker", "1");

		If (T != 0)	{
			String Ts = integertoString(M) + ":" + Ss;
			Song.setText(name + " (" + Ts + ")");
		}
		else Song.setText(name+"    ");

		if(getPlayItemMetaDataString("artist")=="")	{Artist.setText("by "+"???");}
		else Artist.setText("by "+system.getPlayItemMetaDataString("artist"));
		
		if(system.getPlayItemMetaDataString("album") == ""){Album.setText("");}
		
		if(system.getPlayItemMetaDataString("album") != ""){
			if(system.getPlayItemMetaDataString("track") >= "0")
					Album.setText(system.getPlayItemMetaDataString("album") + " (Track " + system.getPlayItemMetaDataString("track") + ")");
				else
					Album.setText(system.getPlayItemMetaDataString("album"));
		}
		else {
			Album.setText("");
		}
	}//!stream
	
	if(stream){
		Nexttrack.setText("On Air");

		Song.setXmlParam("ticker", "1");
		Song.setXmlParam("display", "songtitle");
		Song.setText("");

		if (!isVideo()) Artist.setText("Internet Radio");
		else Artist.setText("Internet TV");

		Album.setText("");
		Album.setXmlParam("display", "songinfo");
	}//stream

	PLEntry.setText(PlCur + "/" + PLTot);
}

SetSize() {
	//string pos = system.getPrivateString("Abducted_OpenNote", "NotifierPosition", "1. Bottom Right");
	string pos_v = myattr_notifierTopBottom.getData();//0=Top 1=Bottom
	string pos_h = myattr_notifierLeftRight.getData();//0=Left 1=Right

	Int ScreenW = system.getViewPortWidth();
	Int ScreenH = system.getViewportHeight();
	Int TitleW = System.strlen(Song.getText());
		
	Wide = artist.getAutoWidth();
	if (Wide < Album.getAutoWidth()) Wide = album.getAutoWidth();
	if (Wide < Song.getAutoWidth()) Wide = Song.getAutoWidth();
	if (Wide < 128) Wide = 150;
	if (Wide > getViewportWidth()/4) Wide = getViewportWidth()/4;

	Wide=Wide+40;

	//if(CDCover.isChecked() == 1)
	/*if(myattr_notifierAlbumCover.getData() == "1") {
		Wide = Wide + 70;
		PhysicalCover.show();
		Texts.setXMLParam("x","70");
		Texts.setXMLParam("w","-70");
	}
	else
	{*/
		//PhysicalCover.hide();
		Texts.setXMLParam("x","0");
		Texts.setXMLParam("w","-0");
	//}
	
	//if(pos=="1. Bottom Right"){
	if(pos_v == "1" && pos_h == "1"){
		Position="b";
		Notifier.setXMLParam("x",integertostring(ScreenW-Wide));
		Notifier.setXMLParam("y",integertostring(ScreenH-85));
	}
	//if(pos=="2. Bottom Left"){
	if(pos_v == "1" && pos_h == "0"){
		Position="b";
		Notifier.setXMLParam("x",integertostring(0));
		Notifier.setXMLParam("y",integertostring(ScreenH-85));
	}
	//if(pos=="3. Top Right"){
	if(pos_v == "0" && pos_h == "1"){
		Position="t";
		Notifier.setXMLParam("x",integertostring(ScreenW-Wide));
		Notifier.setXMLParam("y",integertostring(0));
	}
	//if(pos=="4. Top Left"){
	if(pos_v == "0" && pos_h == "0"){
		Position="t";
		Notifier.setXMLParam("x",integertostring(0));
		Notifier.setXMLParam("y",integertostring(0));
	}

	Notifier.setXMLParam("h",integertostring(80));
	Notifier.setXMLParam("w",integertostring(Wide));
}

Go(Float Fadein,Float Fadeout) {
	Tracker = 1;
	//if(FadeEffect.isChecked() == 1) {
	if (myattr_notifierFadeEffect.getData() == "1") {
		Notifier.show();
		Notifier.setTargetA(255);
		Notifier.setTargetY(StringToInteger(Notifier.getXMLParam("y")));
		Notifier.SetTargetW(Wide);
		Notifier.setTargetX(StringToInteger(Notifier.getXMLParam("x")));
		Notifier.setTargetSpeed(Fadein);
		Notifier.gotoTarget();
	}
	else {
		Notifier.setAlpha(255);
		Notifier.show();
		Notifier.setTargetA(255);
		Notifier.setTargetY(StringToInteger(Notifier.getXMLParam("y")));
		Notifier.SetTargetW(Wide);
		Notifier.setTargetX(StringToInteger(Notifier.getXMLParam("x")));
		Notifier.setTargetSpeed(Fadein);
		Notifier.gotoTarget();
	}
}

Notifier.onTargetReached() {
	if (Tracker == 1) {
		Stay.start();
	}
	if (Tracker == 2) {
		Notifier.hide();
	}
}
	
Stay.onTimer() {
	Stay.stop();
	Tracker = 2;
	//if(FadeEffect.isChecked() == 1) {
	if (myattr_notifierFadeEffect.getData() == "1") {
		Notifier.setTargetA(0);
		Notifier.setTargetY(StringToInteger(Notifier.getXMLParam("y")));
		Notifier.SetTargetW(Wide);
		Notifier.setTargetX(StringToInteger(Notifier.getXMLParam("x")));
		Notifier.setTargetSpeed(Fadeout);
		Notifier.gotoTarget();
	}
	else
	{
		Notifier.show();
		Notifier.setTargetA(255);

		if(position == "b") Notifier.setTargetY(StringToInteger(Notifier.getXMLParam("y"))+90);
		if(position == "t") Notifier.setTargetY(StringToInteger(Notifier.getXMLParam("y"))-90);

		Notifier.SetTargetW(Wide);
		Notifier.setTargetX(StringToInteger(Notifier.getXMLParam("x")));
		Notifier.setTargetSpeed(Fadein);
		Notifier.gotoTarget();
	}
}
