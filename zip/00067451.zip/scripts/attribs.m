#ifndef included
#error This script can only be compiled as a #include
#endif

#ifndef __ATTRIBS_M
#define __ATTRIBS_M

#include <lib/config.mi>
#include "appname.m"

// -----------------------------------------------------------------------------------------------------------------

#ifdef WINAMP5

// this is the page that maps its items to the options menu, you can add attribs or more pages (submenus)
#define CUSTOM_OPTIONSMENU_ITEMS "{1828D28F-78DD-4647-8532-EBA504B8FC04}"

// this is the page that maps its items to the windows menu (aka View), you can add attribs or more pages (submenus)
#define CUSTOM_WINDOWSMENU_ITEMS "{6559CA61-7EB2-4415-A8A9-A2AEEF762B7F}"

#endif

// custom options submenu item page, you can add more, just use guidgen and Config.newItem()
#define CUSTOM_PAGE "{9924D4DF-B776-48b4-8BC9-DC26D8BD13E4}"
/*
// {9924D4DF-B776-48b4-8BC9-DC26D8BD13E4}
static const GUID <<name>> = 
{ 0x9924d4df, 0xb776, 0x48b4, { 0x8b, 0xc9, 0xdc, 0x26, 0xd8, 0xbd, 0x13, 0xe4 } };
*/

// notifier config page
#define CUSTOM_PAGE_NOTIFIER "{FF0D111F-D087-470f-B539-32799879B78F}"
/*
// {FF0D111F-D087-470f-B539-32799879B78F}
static const GUID <<name>> = 
{ 0xff0d111f, 0xd087, 0x470f, { 0xb5, 0x39, 0x32, 0x79, 0x98, 0x79, 0xb7, 0x8f } };
*/

#define CUSTOM_PAGE2_NOTIFIER "{A66555AC-E4CA-4557-AF11-3175A61DF774}"
/*
// {258968BA-8E47-453c-A008-4433A6EB298E}
static const GUID <<name>> = 
{ 0x258968ba, 0x8e47, 0x453c, { 0xa0, 0x8, 0x44, 0x33, 0xa6, 0xeb, 0x29, 0x8e } };
*/

// -----------------------------------------------------------------------------------------------------------------

Function initAttribs();

// -----------------------------------------------------------------------------------------------------------------

Global ConfigAttribute myattr_scrollSongticker;
Global ConfigAttribute myattr_animateDrawer;
Global ConfigAttribute myattr_alwaysOnTop;
Global ConfigAttribute myattr_enableTooltips;
Global ConfigAttribute myattr_dockWindows;
Global ConfigAttribute myattr_windowshade_linkposition;

//Global ConfigAttribute myattr_visMode;

Global ConfigAttribute myattr_notifierAlways;
Global ConfigAttribute myattr_notifierWindowshade;
Global ConfigAttribute myattr_notifierMinimized;
Global ConfigAttribute myattr_notifierNever;
Global ConfigAttribute myattr_notifierDisableFullscreen;
Global ConfigAttribute myattr_notifierAlbumCover;

Global ConfigAttribute myattr_notifierFadeEffect;
Global ConfigAttribute myattr_notifierSlideEffect;

Global ConfigAttribute myattr_notifierFadeInTime;
Global ConfigAttribute myattr_notifierHoldTime;
Global ConfigAttribute myattr_notifierFadeOutTime;
Global ConfigAttribute myattr_notifierShadowOpacity;

Global ConfigAttribute myattr_notifierTopBottom;
Global ConfigAttribute myattr_notifierLeftRight;
//get some already existing configattribs
Global ConfigAttribute attr_aot, attr_tooltips, attr_dockwindows;

//Global ConfigAttribute myattr_lastWindow;  //last window mode other than the shade(stick) mode i.e. "normal" or "compact"
// -----------------------------------------------------------------------------------------------------------------

initAttribs() {

	// create the custom cfgpage for this session (if it does exist, it just returns it)
	ConfigItem custom_page = Config.newItem("StarTrek LCARS AMP PADD II", CUSTOM_PAGE);
	ConfigItem custom_page_notifier = Config.newItem("Notifications", CUSTOM_PAGE_NOTIFIER);

#ifdef WASABI_PLAYER
	//no reason to keep in an other cfg group if it cannot be hidden from the config registry
	ConfigItem hidden_page = Config.newItem("StarTrek LCARS AMP PADD II", CUSTOM_PAGE2_NOTIFIER);
#endif

#ifdef WINAMP5

	ConfigItem hidden_page = Config.newItem("StarTrek LCARS AMP PADD II Hidden", CUSTOM_PAGE2_NOTIFIER);

	// load up the cfgpage in which we'll insert our custom page
	ConfigItem custom_options_page = Config.getItem(CUSTOM_OPTIONSMENU_ITEMS);

	// this creates a submenu for this attribute
	ConfigAttribute submenuattrib = custom_options_page.newAttribute("StarTrek LCARS AMP PADD II", "");
	submenuattrib.setData(CUSTOM_PAGE); // discard any default value and point at our custom cfgpage

	ConfigAttribute notifiersubmenu = custom_page.newAttribute("Notifications", "");
	notifiersubmenu.setData(CUSTOM_PAGE_NOTIFIER);
#endif

	myattr_scrollSongticker = custom_page.newAttribute("Scroll Songticker", "1");
	myattr_animateDrawer = custom_page.newAttribute("Animate Drawer", "1");
	myattr_alwaysOnTop = custom_page.newAttribute("Always On Top", "1");
	myattr_enableTooltips = custom_page.newAttribute("Enable Tooltips", "1");
	myattr_dockWindows = custom_page.newAttribute("Dock Windows", "1");
	myattr_windowshade_linkposition = custom_page.newAttribute("Link Position", "1");

	//myattr_visMode = hidden_page.newAttribute("Vis Mode", "1");

	myattr_notifierAlways = custom_page_notifier.newAttribute("Show Always", "0");
	myattr_notifierWindowshade = custom_page_notifier.newAttribute("Show With Stick And When Minimized", "0");
	myattr_notifierMinimized = custom_page_notifier.newAttribute("Show Only When Minimized", "0");
	myattr_notifierNever = custom_page_notifier.newAttribute("Never Show", "1");
#ifdef WINAMP5
	ConfigAttribute sep = custom_page_notifier.newAttribute("sep1", ""); sep.setData("-");
#endif
	myattr_notifierDisableFullscreen = custom_page_notifier.newAttribute("Disable In Fullscreen", "1");
#ifdef WINAMP5
	ConfigAttribute sep = custom_page_notifier.newAttribute("sep2", ""); sep.setData("-");
#endif
//	myattr_notifierAlbumCover = custom_page_notifier.newAttribute("Show Album Cover", "0");
//#ifdef WINAMP5
//	ConfigAttribute sep = custom_page_notifier.newAttribute("sep3", ""); sep.setData("-");
//#endif
	myattr_notifierFadeEffect = custom_page_notifier.newAttribute("Fade Effect", "1");
	myattr_notifierSlideEffect = custom_page_notifier.newAttribute("Slide Effect", "0");

	myattr_notifierFadeInTime = hidden_page.newAttribute("Notifications fade in time", "1000");
	myattr_notifierHoldTime = hidden_page.newAttribute("Notifications Display Time", "2000");
	myattr_notifierFadeOutTime = hidden_page.newAttribute("Notifications fade out time", "5000");
	myattr_notifierShadowOpacity = hidden_page.newAttribute("Notifications shadow opacity", "255");

	myattr_notifierTopBottom = hidden_page.newAttribute("TopBottom", "1");//0=Top 1=Bottom
	myattr_notifierLeftRight = hidden_page.newAttribute("LeftRight", "1");//0=Left 1=Right

	//myattr_lastWindow = hidden_page.newAttribute("Last window mode", "normal");

    ConfigItem item;
    item = Config.getItem("Options");
    if (item != NULL) {
      attr_aot = item.getAttribute("Always on top");
      attr_dockwindows = item.getAttribute("Enable docking");
    }
    item = Config.getItem("Skins and UI Tweaks");
    if (item != NULL) {
      attr_tooltips = item.getAttribute("Enable tooltips");
    }

}

// -----------------------------------------------------------------------------------------------------------------

#endif
