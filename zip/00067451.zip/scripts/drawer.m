/*-----------------------------------------------------------------------------
 drawer.m
 by Jason Chiu
 based on drawer.m by FrisbeeMonkey (www.frisbeemonkey.com)
 GOTO www.frisbeemonkey.com to get the ORIGINAL maki script.
 -----------------------------------------------------------------------------*/


#include <lib/std.mi>
#include <lib/pldir.mi>
#include "attribs.m"

Function InitVars();
Function THDrawerShow();
Function THDrawerHide();
Function CTDrawerShow();
Function CTDrawerHide();
Function EQDrawerShow();
Function EQDrawerHide();
Function Main_drawerDrawerOpen();
Function Main_drawerDrawerClose();


//declares global variables for use in script
Global Group THonScreenGroup, THbtnLocation, CTonScreenGroup, CTbtnLocation, EQonScreenGroup, EQbtnLocation, Main_draweronScreenGroup, Main_drawerbtnLocation;
Global Group Configpage1, Configpage2, Configpage3;
Global Layer THDrawer, THDrawerInfo, CTDrawer, CTDrawerInfo, EQDrawer, EQDrawerInfo, Main_drawerDrawer, Main_drawerDrawerInfo;
Global button THBtn, CTBtn, EQBtn, Main_drawerBtn, Nextcfgpage2, Prevcfgpage1, Nextcfgpage3, Prevcfgpage2;
Global Boolean THDrawerStatus, CTDrawerStatus, EQDrawerStatus; //0 = invisible, 1 = visible
Global Int Main_drawerStartX, Main_drawerStartY, Main_drawerEndX, Main_drawerEndY;
Global Layout normal;
Global Boolean DrawerOut, AnimateDrawer; //0 = closed, 1 = open

InitVars() {
	Main_drawerDrawer = Main_draweronScreenGroup.findObject("Drawer");
	Main_drawerDrawerInfo = Main_draweronScreenGroup.findObject("DrawerInfo");

	THBtn = THbtnLocation.findObject("th");
	CTBtn = CTbtnLocation.findObject("ct");
	EQBtn = EQbtnLocation.findObject("eql");
	Main_drawerBtn = Main_drawerbtnLocation.findObject("eql");

	Configpage1 = normal.findObject("Configpage1");
	Configpage2 = normal.findObject("Configpage2");
	Configpage3 = normal.findObject("Configpage3");

	Nextcfgpage2 = Configpage1.findObject("Nextcfgpage2");
	Prevcfgpage1 = Configpage2.findObject("Prevcfgpage1");
	Nextcfgpage3 = Configpage2.findObject("Nextcfgpage3");
	Prevcfgpage2 = Configpage3.findObject("Prevcfgpage2");

	Main_drawerStartX = StringToInteger(Main_draweronScreenGroup.getXMLparam("x"));
	Main_drawerStartY = StringToInteger(Main_draweronScreenGroup.getXMLparam("y"));
	Main_drawerEndX = StringToInteger(Main_drawerDrawerInfo.getXMLparam("x"));
	Main_drawerEndY = StringToInteger(Main_drawerDrawerInfo.getXMLparam("y"));

	//initialize all our drawers flag to invisible
	THDrawerStatus = 0;
	CTDrawerStatus = 0;
	EQDrawerStatus = 0;

	//DrawerOut = getPrivateInt("StarTrek LCARS AMP PADD II", "DrawerOut", 0);
	AnimateDrawer = stringToInteger(myattr_animateDrawer.getData());

	//set totally transparent
	if (AnimateDrawer) {
		THonScreenGroup.setAlpha(0);
		CTonScreenGroup.setAlpha(0);
		EQonScreenGroup.setAlpha(0);
	} else {
		THonScreenGroup.setAlpha(255);
		CTonScreenGroup.setAlpha(255);
		EQonScreenGroup.setAlpha(255);
	}

	EQonScreenGroup.hide();
	THonScreenGroup.hide();
	CTonScreenGroup.hide(); //hide color themes drawer to prevent it from overriding up/down arrows
}

/*System.onScriptUnloading() {
	setPrivateInt("StarTrek LCARS AMP PADD II","DrawerOut", DrawerOut);
}*/


/** Open and Close Logic **/
//when the left mouse button is released within Drawer, do this
THBtn.onLeftClick() {
		if (DrawerOut == 0 )	Main_drawerDrawerOpen();
		if (THDrawerStatus == 0) {  // if our Drawer is closed, make it slide open
			if (EQDrawerStatus == 1) EQDrawerHide();
			else if (CTDrawerStatus == 1) CTDrawerHide();
			THDrawerShow();
		}
		else {  // if our Drawer is open, make it slide closed
			Main_drawerDrawerClose();
			THDrawerHide();
		}
}

//when the left mouse button is released within Drawer, do this
CTBtn.onLeftClick() {
		if (DrawerOut == 0 )	Main_drawerDrawerOpen();
		if (CTDrawerStatus == 0) {  // if our Drawer is closed, make it slide open
			if (EQDrawerStatus == 1) EQDrawerHide();
			else if (THDrawerStatus == 1) THDrawerHide();
			CTDrawerShow();
		}
		else {  // if our Drawer is open, make it slide closed
			Main_drawerDrawerClose();
			CTDrawerHide();
		}
}

//when the left mouse button is released within Drawer, do this
EQBtn.onLeftClick() {
		if (DrawerOut == 0 )	Main_drawerDrawerOpen();
		if (EQDrawerStatus == 0) {  // if our Drawer is closed, make it slide open
			if (CTDrawerStatus == 1) CTDrawerHide();
			else if (THDrawerStatus == 1) THDrawerHide();
			EQDrawerShow();
		}
		else {  // if our Drawer is open, make it slide closed
			Main_drawerDrawerClose();
			EQDrawerHide();
		}
}

/***** Show and Hide Operations *******/
//Show and Shide THDrawer Function
THDrawerShow() {  // if our Drawer is closed, make it slide open
//    if (!Main_draweronScreenGroup.isGoingToTarget()) {  //makes sure it isn't already moving
		THBtn.setActivated(1);
		THonScreenGroup.show();
		if (AnimateDrawer) {
			THonScreenGroup.setTargetA(255); //set totally opaque
			THonScreenGroup.setTargetSpeed(1);
			THonScreenGroup.gotoTarget();
		}
		else THonScreenGroup.setAlpha(255);
		THDrawerStatus = 1;  //Change the flag to visible
  //  }
}

THDrawerHide() {  // if our Drawer is open, make it slide closed
	THBtn.setActivated(0);
	if (AnimateDrawer) {
		THonScreenGroup.setTargetA(0);
		THonScreenGroup.setTargetSpeed(1);
		THonScreenGroup.gotoTarget();
	}
	THonScreenGroup.hide();
	THDrawerStatus = 0;  //Change the flag to invisible
}


//Show and Hide CTDrawer Functions
/*
	IMPORTANT the .hide() and .show() pair are needed to prevent the ColorTheme:List from
	overriding the up and down arrows and scroll wheel, which controls the volume
*/
CTDrawerShow() {  // if our Drawer is closed, make it slide open
//  if (!Main_draweronScreenGroup.isGoingToTarget()) {  //makes sure it isn't already moving
		CTBtn.setActivated(1);
		CTonScreenGroup.show();
		if (AnimateDrawer) {
			CTonScreenGroup.setTargetA(255); //set totally opaque
			CTonScreenGroup.setTargetSpeed(1);
			CTonScreenGroup.gotoTarget();
		}
		else CTonScreenGroup.setAlpha(255);
		CTDrawerStatus = 1;  //Change the flag to visible
  // }
}

CTDrawerHide() {  // if our Drawer is open, make it slide closed
	CTBtn.setActivated(0);
	if (AnimateDrawer) {
		CTonScreenGroup.setTargetA(0);
		CTonScreenGroup.setTargetSpeed(1);
		CTonScreenGroup.gotoTarget();
	}
	CTonScreenGroup.hide();
	CTDrawerStatus = 0;  //Change the flag to invisible
}

//Show and Hide EQDrawer Functions
EQDrawerShow() {  // if our Drawer is closed, make it slide open
//    if (!Main_draweronScreenGroup.isGoingToTarget()) {  //makes sure it isn't already moving
		EQBtn.setActivated(1);
		EQonScreenGroup.show();
		if (AnimateDrawer) {
			EQonScreenGroup.setTargetA(255); //set totally opaque
			EQonScreenGroup.setTargetSpeed(1);
			EQonScreenGroup.gotoTarget();
		}
		else EQonScreenGroup.setAlpha(255);
		EQDrawerStatus = 1;  //Change the flag to visible
  //  }
}

EQDrawerHide() {  // if our Drawer is open, make it slide closed
	EQBtn.setActivated(0);
	if (AnimateDrawer) {
		EQonScreenGroup.setTargetA(0);
		EQonScreenGroup.setTargetSpeed(1);
		EQonScreenGroup.gotoTarget();
	}
	EQonScreenGroup.hide();
	EQDrawerStatus = 0;  //Change the flag to invisible
}


/* Config page Display */
Nextcfgpage2.onLeftClick() {
	Configpage1.setXmlParam("visible", "0");
	Configpage2.setXmlParam("visible", "1");
	Configpage3.setXmlParam("visible", "0");
}

Prevcfgpage1.onLeftClick() {
	Configpage1.setXmlParam("visible", "1");
	Configpage2.setXmlParam("visible", "0");
	Configpage3.setXmlParam("visible", "0");
}

Nextcfgpage3.onLeftClick() {
	Configpage1.setXmlParam("visible", "0");
	Configpage2.setXmlParam("visible", "0");
	Configpage3.setXmlParam("visible", "1");
}

Prevcfgpage2.onLeftClick() {
	Configpage1.setXmlParam("visible", "0");
	Configpage2.setXmlParam("visible", "1");
	Configpage3.setXmlParam("visible", "0");
}
