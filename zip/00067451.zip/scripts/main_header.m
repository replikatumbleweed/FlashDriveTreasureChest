/*--------------------------------------------------------------------
 Main/Normal player group script this is a "header" file used by main.m and shade.m.
 Modified for Star Trek LCARS AMP PADD II (its songticker is not in the play buttons group)
 
 - integrated FrisbeeMonkey's autorepeatvolumebuttons.m
 - integrated Digitalhigh's seekbuttons.m and improved it so that it works like FrisbeeMonkey's autorepeatvolumebuttons.m
--------------------------------------------------------------------*/

#include </lib/std.mi>
#include </lib/pldir.mi>
#include "appname.m"
#include "attribs.m"
#include "AutoRepeatButton.m" //Include the AutoRepeatButton Library

Function setTempText(String txt);
Function printSeekPosition(int p);

Global Text Songticker;
Global Slider Volbar,Seeker,SeekGhost;
Global Timer SongTickerTimer;
Global Int Seeking;

Global Togglebutton ShuffleBtn,RepeatBtn,CrossfadeBtn;

//autorepeatvolumebuttons
Global AutoRepeatButton VolumeUp,VolumeDown,Rew5s,Fwd5s; //Define our buttons, note the use of AutoRepeatButton as opposed to just Button
Global float CurrentVolume; //Define a volume var that is floating point, so that we can go in 2.55 (1%) jumps

Global Boolean ScrollTicker;


System.onScriptUnloading() {
	AutoRepeat_UnLoad();  //This must be done in all scripts using the AutoRepeatButton library
	delete SongTickerTimer;  //timers are big CPU drainers
}
//YOU MUST IMPLEMENT System.onScriptLoading() in your main.m and shade.m


setTempText(String txt) {
	SongTickerTimer.start();
	Songticker.setAlternateText(txt);
}

SongTickerTimer.onTimer() {
  SongTicker.setText("");
  SongTickerTimer.stop();
}


myattr_scrollSongticker.onDataChanged() {
  ScrollTicker = stringToInteger(myattr_scrollSongticker.getData());
  if (ScrollTicker) Songticker.setXmlParam("ticker", "1");
  else Songticker.setXmlParam("ticker", "0");
}



Songticker.onLeftButtonDblClk(int x, int y) {
	PlDir.showCurrentlyPlayingEntry();
}

Volbar.onSetPosition(int p) {
	Float f;
	f = p;
	f = f / 255 * 100;
	setTempText("Volume: " + System.integerToString(f) + "%");
}

Volbar.onSetFinalPosition(int p) {
	Songticker.setAlternateText("");
}

//commented out:  conflicts with mute.m
/*System.onVolumeChanged(int p) {
	Float f;
	f = p;
	f = f / 255 * 100;
	setTempText("Volume: " + System.integerToString(f) + "%");
}*/

Seeker.onSetPosition(int p) {
  if (!SeekGhost && seeking) {
    Float f;
    f = p;
    f = f / 255 * 100;
    Float len = getPlayItemLength();
    if (len != 0) {
      int np = len * f / 100;
      setTempText("Seek to " + integerToTime(np) + " / " + integerToTime(len) + " (" + integerToString(f) + "%)");
    }
  }
}

Seeker.onLeftButtonDown(int x, int y) {
	seeking = 1;
}

Seeker.onLeftButtonUp(int x, int y) {
	seeking = 0;
	setTempText("");
}

SeekGhost.onSetPosition(int p) {
	if (getalpha() == 1) return;
	Float f;
	f = p;
	f = f / 255 * 100;
	Float len = getPlayItemLength();
	if (len != 0) {
		int np = len * f / 100;
		setTempText("Seek to " + integerToTime(np) + " / " + integerToTime(len) + " (" + integerToString(f) + "%)");
	}
}

SeekGhost.onLeftButtonDown(int x, int y) {
	SeekGhost.setAlpha(128);
}

SeekGhost.onLeftButtonUp(int x, int y) {
	SeekGhost.setAlpha(1);
}

Seeker.onSetFinalPosition(int p) {
	Songticker.setAlternateText("");
}

SeekGhost.onsetfinalposition(int p) {
	Songticker.setAlternateText("");
	SeekGhost.setAlpha(1);
}

RepeatBtn.onToggle(boolean on) {
	SongTickerTimer.start();
	int v = getCurCfgVal();
	if (v == 0) setTempText("Repeat: OFF");
	else if (v == 1) setTempText("Repeat: ALL");
	else if (v == 2) setTempText("Repeat: TRACK");
}

ShuffleBtn.onToggle(boolean on) {
	SongTickerTimer.start();
	if (on) setTempText("Playlist Shuffling: ON");
	else setTempText("Playlist Shuffling: OFF");
}

CrossfadeBtn.onToggle(boolean on) {
	SongTickerTimer.start();
	if (on) setTempText("Crossfading: ON");
	else setTempText("Crossfading: OFF");
}

//FrisbeeMonkey's autorepeatvolumebuttons code BEGINS
System.onVolumeChanged(int newvol) { //If we did change the volume update CurrentVolume
	if (System.Integer(CurrentVolume) != newvol) {
		CurrentVolume = Newvol;
	}
}

VolumeUp.onLeftClick() {  //this contains the code for clicks AND NOW autorepeats of VolumeUp
	if (AutoRepeat_ClickType != 0) {  //use this to avoid calls to this that the AutoRepeatLibrary didn't want
		/*Here goes all the code to do when the button is pressed, for now lets just increase the volume by 1% */
		CurrentVolume = CurrentVolume + 2.55; //increase the currentvolume by 2.55 (1%)
		System.SetVolume(system.integer(CurrentVolume)); //set the new volume level
		setTempText("Volume: " + System.IntegertoString(CurrentVolume/2.55) + "%"); //update the SongTicker
	}
}

VolumeDown.onLeftClick() {  //this contains the code for clicks AND NOW autorepeats of VolumeDown
	if (AutoRepeat_ClickType != 0) {  //use this to avoid calls to this that the AutoRepeatLibrary didn't want
		/*Here goes all the code to do when the button is pressed, for now lets just decrease the volume by 1% */
		CurrentVolume = CurrentVolume - 2.55; //decrease the currentvolume by 2.55 (1%)
		System.SetVolume(system.integer(CurrentVolume)); //set the new volume level
		setTempText("Volume: " + System.IntegertoString(CurrentVolume/2.55) + "%"); //update the SongTicker
	}
}
//FrisbeeMonkey's autorepeatvolumebuttons code END
printSeekPosition(int p) {
	Float len = getPlayItemLength();
	Float f = p / len * 100;
	if (len != 0) {
		setTempText("Seek to " + integerToTime(p) + " / " + integerToTime(len) + " (" + integerToString(f) + "%)");
	}
}

//DigitalHigh's seekbuttons code BEGINS
Rew5s.onLeftClick() {  //this contains the code for clicks AND NOW autorepeats of VolumeUp
	int p, a;
	if (AutoRepeat_ClickType != 0) {  //use this to avoid calls to this that the AutoRepeatLibrary didn't want
		p = System.getposition();  //gets the current song position
		p -= a;  //sets the position back by a, which is currently 100
		a += 50;  //adds 50 to it, so the seekspeed increases
		if (p <= 0) {  //if we get to the end of the song
			System.previous();  //skip to the previous song
			a = 100;  //resets the seeksepeed to 100 again
		    p = ((System.getPlayItemLength() * 1000) - 1); // gets the length of the song and goes to the end
			//system.seekto(p);//starts seeking back again
			//system.play();  //triggers the play command to show the new song
		} else {
			system.seekTo(p);   //otherwise, seek backwards
			printSeekPosition(p);
		}
	}
}

Fwd5s.onLeftClick() {  //this contains the code for clicks AND NOW autorepeats of VolumeDown
	int p, a;
	if (AutoRepeat_ClickType != 0) {  //use this to avoid calls to this that the AutoRepeatLibrary didn't want
		p = System.getposition();
		p += a;
		a += 50;
		if (p >= System.getPlayItemLength() + 5) {
			System.next();
			a = 100;
			p = (0);
		} else {
			system.seekTo(p);
			printSeekPosition(p);
		}
	}
}
//DigitalHigh's seekbuttons code END
