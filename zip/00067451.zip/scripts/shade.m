/*--------------------------------------------------------------------
 Main/Shade player group script.
 For Star Trek LCARS AMP PADD II
--------------------------------------------------------------------*/

#include "main_header.m" //Include the main_header Library

//Function initCustomSongticker();

Class Button HintObject;
Global HintObject Eq, Ml, Pl, Ct;
Global Text infolineText;
Global Layer master_dblClickAction_SWITCH;
Global Container mainContainer;

System.onScriptLoaded() {
	initAttribs();
	//AutoRepeat_Load();  //This must be done in all scripts using the AutoRepeatButton library
	Group pgroup = getScriptGroup();

	// Get songticker, Volbar & Seeker
	Songticker = pgroup.findObject("Songticker");
	if (songticker == null) messagebox("ooch!!", "ooch", 0, "");
	
	infolineText = pgroup.getObject("infoline");

	Volbar = pgroup.findObject("Volume");
	Seeker = pgroup.findObject("Seeker");
	SeekGhost = pgroup.findObject("SeekerGhost");

	RepeatBtn = pgroup.findObject("Repeat");
	ShuffleBtn = pgroup.findObject("Shuffle");
	CrossfadeBtn = pgroup.findObject("Crossfade");

	Eq = pgroup.findObject("eql");
	Ml = pgroup.findObject("ml");
	Pl = pgroup.findObject("pl");
	Ct = pgroup.findObject("ct");

	//autorepeatvolumebuttons
	//VolumeUp = pgroup.getObject("VolumeUp");
	//VolumeDown = pgroup.getObject("VolumeDown");
	CurrentVolume = System.GetVolume(); //start off out Current Volume var

	if (SeekGhost != NULL) SeekGhost.setAlpha(1);

	SongTickerTimer = new Timer;
	SongTickerTimer.setDelay(1000);

	ScrollTicker = stringToInteger(myattr_scrollSongticker.getData());
	if (!ScrollTicker) Songticker.setXmlParam("ticker", "0");

	master_dblClickAction_SWITCH = pgroup.findObject("master_dblClickAction_SWITCH");
	mainContainer = getContainer("main");
	if( System.getPrivateString("StarTrekLCARSAmpPaddII","shadeMode","") == "" )
		System.setPrivateString("StarTrekLCARSAmpPaddII","shadeMode","normal");

	myattr_windowshade_linkposition.onDataChanged();
	//initCustomSongticker();
}

HintObject.onLeftClick() {
	if (HintObject == Pl) setTempText("Playlist Editor");
	else if (HintObject == Ml) setTempText("Media Library");
	else if (HintObject == Eq) setTempText("Equalizer");
	else if (HintObject == Ct) setTempText("Gamma Presets");
}


master_dblClickAction_SWITCH.onLeftButtonDblClk(int x, int y) {
	Container c = getContainer("main");
	//c.switchToLayout(myattr_lastWindow.getData());
	c.switchToLayout(System.getPrivateString("StarTrekLCARSAmpPaddII","shadeMode","normal"));
}
System.onShowLayout(Layout l) {
	//if(l.getId() != "shade") myattr_lastWindow.setData(l.getId());
	if (l == getContainer("main").getLayout("normal") || l == getContainer("main").getLayout("compact"))
		System.setPrivateString("StarTrekLCARSAmpPaddII","shadeMode",l.getId());
}

//shade position linking
myattr_windowshade_linkposition.onDataChanged() {
	if (getData() == "1") {
		Layout shade = getScriptGroup().getParentLayout();
		Layout normal = shade.getContainer().getLayout("normal");
		shade.setXmlParam("unlinked", "0");
	}
	if (getData() == "0") {
		Layout shade = getScriptGroup().getParentLayout();
		Layout normal = shade.getContainer().getLayout("normal");
		shade.setXmlParam("unlinked", "1");
	}
}

/*SongTickerTimer.onTimer() {
	Float len = getPlayItemLength();
	SongTicker.setText(
		System.getPlayItemMetaDataString("Artist")
		+ " - " + System.getPlayItemMetaDataString("Title")
		+ " (" + integerToTime(len) + ")   ---   "
		+  System.getSongInfoText()
	);
	SongTickerTimer.stop();
}

System.onPlay() {
	initCustomSongticker();
}

initCustomSongticker() {
	SongTickerTimer.start();
	Float len = getPlayItemLength();
	SongTicker.setText(
		System.getPlayItemMetaDataString("Artist")
		+ " - " + System.getPlayItemMetaDataString("Title")
		+ " (" + integerToTime(len) + ")   ---   "
		+  System.getSongInfoText()
	);
	SongTickerTimer.stop();
}*/

/*System.getSongInfoText();
System.getPlayItemLength(); //in seconds int

System.getPlayItemMetaDataString("Title");
System.getPlayItemMetaDataString("Artist");
System.getPlayItemMetaDataString("Name");
System.getPlayItemMetaDataString("Album");
System.getPlayItemMetaDataString("Genre");*/
