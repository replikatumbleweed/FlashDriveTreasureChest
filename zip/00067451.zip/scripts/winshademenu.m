/*-----------------------------------------------------------------------------
  winshademenu.m

  by Plague (Linus Brolin)
-----------------------------------------------------------------------------*/

#include </lib/std.mi>

Global Container main;
Global Layout normal, compact, shade;
Global Button Winshade;
Global Popupmenu winshadeMenu;
Global Int choice;

System.onScriptUnloading() {
	delete winshadeMenu;
}

System.onScriptLoaded() {
	main = getContainer("main");
	normal = main.getLayout("normal");
	compact = main.getLayout("compact");
	shade = main.getLayout("shade");

	Group pgroup = getScriptGroup();
	Winshade = pgroup.findObject("Winshade");

	winshadeMenu = New PopupMenu;
	winshadeMenu.addCommand("Normal ",1,0,0);
	winshadeMenu.addCommand("Compact ",2,0,0);
	winshadeMenu.addCommand("Shade ",3,0,0);
}

Winshade.onRightButtonUp(int x, int y) {
	if (isObjectValid(normal)) winshadeMenu.checkCommand(1, normal.isVisible());
	if (isObjectValid(compact)) winshadeMenu.checkCommand(2, compact.isVisible());
	if (isObjectValid(shade)) winshadeMenu.checkCommand(3, shade.isVisible());
	choice = winshadeMenu.popAtMouse();

	if (choice == 1) main.switchToLayout("normal");
	else if (choice == 2) main.switchToLayout("compact");
	else if (choice == 3) main.switchToLayout("shade");
	Complete;
}
