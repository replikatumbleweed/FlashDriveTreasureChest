//-----------------------------------------------------------------------------
// stopaftersong.m
//
// Example of a stop-after-current-song button
//
// created by FrisbeeMonkey
//-----------------------------------------------------------------------------

//                            USING THIS SCRIPT:
//*****************************************************************************
//  1.  Define the following in your XML:
//    <togglebutton
//      id="StopAfterSong"
//      x="147" y="89"
//      image="player.StopAfterSongOff"
//      downImage="player.StopAfterSongOn"
//	    activeImage="player.StopAfterSongOn"
//      tooltip="StopAfterSong"
//    />
//         Change the position(x,y) to the specifics of your button,
//  2.  Make sure your ticker is called "SongTicker" and is in the same group as
//      "StopAfterSong"  If you don't have a ticker, add one now.  Also, have
//		a CrossFade button somewhere in the group or one of it's subgroups.  Make
//		sure it is a togglebutton, and that it is named "CrossFade".
//  4.  Copy this script (and StopAfterSong.maki) to your scripts folder.
//  5.  If you don't have StopAfterSong.maki, compile this script.
//  6.  Add this line to the group that contains your animated layer
//        <script id="StopAfterSong" file="scripts/StopAfterSong.maki"/>
//  7.  Refresh your skin(F5) and try it out.
//*****************************************************************************

// never forget to include std.mi
#include "../lib/std.mi"

//declares global variables
Global Togglebutton StopAfterSongBtn, XFadeBtn;
Global Timer SongTickerTimer;
Global Text SongTicker;
Global Boolean StopAfter, XFade;
Global Group pcGroup;

//When the script is loaded, do this
System.onScriptLoaded() {

	// Get the group that has the objects we want
	pcGroup = getScriptGroup();

	// Now that we have the group, get the objects in the group
	StopAfterSongBtn = pcGroup.findObject("StopAfterSong");
	XFadeBtn = pcGroup.findObject("Crossfade");
	SongTicker = pcGroup.findObject("songticker");

	// Initialize our timer
	SongTickerTimer = new Timer;
	SongTickerTimer.setDelay(500);

	//sets StopAfter and XFade flags to 0
	StopAfter = 0;
	XFade = 0;
}

// Clears text area
SongTickerTimer.onTimer() {
  SongTicker.setText("");
  SongTickerTimer.stop();
}

// If buttons is pressed, stops winamp after current song
System.onTitleChange(string newTitle) {
	if (StopAfter) {
		System.stop();
	}
}

// After stopping on specified song, clears variable so winamp can play normally again
System.onStop() {
	if (StopAfter) {
		StopAfterSongBtn.leftClick();
		StopAfter = 0;
		//if Crossfade was on, re-enable it
		if (XFade) {
			XFadeBtn.leftClick();
		}
	}
}

// If StopAfterSong is clicked, turn on or off
StopAfterSongBtn.onLeftButtonUp(int x, int y) {
	if (StopAfterSongBtn.isMouseOver(x, y)) {  //make sure mouse is released above button
		if (!StopAfter) {  //off to on
			StopAfter = 1;
			SongTickerTimer.start();
			SongTicker.setText("Playback will stop after this song");
			//gets current Crossfade status
			XFade = XFadeBtn.getActivated();
			if (XFade) {
				//toggles crossfade if on
				XFadeBtn.leftClick();
			}
		} else {  //on to off
			StopAfter = 0;
			SongTickerTimer.start();
			SongTicker.setText("Normal playback resumed");
			//if Crossfade was on, re-enable it
			if (XFade) {
				XFadeBtn.leftClick();
			}
		}
	}
}

// when the script is unloading, deletes the Timer
System.onScriptUnloading() {
	delete SongTickerTimer;
}
