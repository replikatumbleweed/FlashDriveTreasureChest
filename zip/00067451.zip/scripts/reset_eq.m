/////////////////////////////////////
// reset_eq.m (Version 1.2)
// Resets all eq bands (and preamp) to zero with a press of a button
// created by Jason Chiu - revised August 2004
/////////////////////////////////////

///////////////////////////////////////
//  1.  Define the following in your XML:
/*
	<button
		id="reset_eq"
		x="0" y="0"
		image="player.reset_eq"
		downImage="player.reset_eq"
		tooltip="Reset all Equalizer Bands to Zero"
	/>
*/
//  2.  Copy this script to your scripts folder.
//  3.  If you don't have reset_eq.maki, compile this script.
//  4.  Add this line to the group that contains the button you created in step 1
//        <script id="resetEQ" file="scripts/reset_eq.maki"/>
//  5.  Refresh your skin(F5) and try it out.
/////////////////////////////////////////


#include <lib/std.mi>

Function setTempText(String txt);
Function emptyTempText();

//declare global variables
Global Button ResetBtn;
Global Timer SongTickerTimer;
Global Text SongTicker;
Global Slider Panning, Crossfade;

//init on script load
System.onScriptLoaded() {
	Group pcGroup = getScriptGroup();
	ResetBtn = pcGroup.findObject("reset_eq");
	SongTicker = pcGroup.findObject("songticker");

	Panning = pcGroup.findObject("Balance");
	Crossfade = pcGroup.findObject("Crossfade");

	SongTickerTimer = new Timer;
	SongTickerTimer.setDelay(750);
}

// Clears text area
SongTickerTimer.onTimer() {
	SongTicker.setText("");
	SongTickerTimer.stop();
}

// reset all bands
ResetBtn.onLeftClick() {
		//range is from -127 to +127 (0 means no preamp).
		System.setEqPreamp(0);
		//bands are numbered from 0 (60Hz) to 9 (16kHz)
		for(int i=0; i<10; i++) System.setEqBand(i, 0);
		
		SongTickerTimer.stop();
		SongTickerTimer.start();
		SongTicker.setText("Equalizer Reset");
}

Panning.onSetPosition(int p) {
	Float f;
	f = p;
	f = f / 255 * 100;
	Float b = 255 / 2;

	if (0 < (f - 50))
		setTempText("Balance:  " + System.integerToString((f - 50) * 2) + "%" + " Right");
	else if (0 > (f - 50))
		setTempText("Balance:  " + System.integerToString((f - 50)* -2) + "%" + " Left");     
	else if(p == b) setTempText("Balance:  Center");
}

Crossfade.onSetPosition(int p) {
	Float f;
	f = p;
	f = f / 255 * 100;
	Float b = 255 / 2;
	if(p != b) setTempText("Crossfade:  " + System.integerToString(f * 2.6) + " seconds");
}

setTempText(String txt) {
	Songticker.setAlternateText(txt);
}

emptyTempText() {
	Songticker.setAlternateText("");
}
