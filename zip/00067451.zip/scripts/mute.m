#include <lib/std.mi>

Function setTempText(String txt);
Function updateVolume(int v);

Global Group frameGroup;
Global Togglebutton MuteBtn,MuteBtnShade;
Global Timer SongTickerTimer, callback;
Global Text SongTicker, SongTickerShade;
Global Float VolumeLevel;
Global Boolean Muted,BtnPressed;
Global Layer volumebar;

System.onScriptLoaded() {

	frameGroup = getScriptGroup();
	MuteBtn = frameGroup.findObject("Mute");

	callback = new Timer;
	callback.setDelay(5);
	callback.start();

	SongTicker = frameGroup.findObject("songticker");

	//volumebar = frameGroup.findObject("volumebar");
	//volumebar.setXmlParam("w",integertostring( (system.getVolume()/255) *70 + 5));

	SongTickerTimer = new Timer;
	SongTickerTimer.setDelay(500);

	Muted = 0;
	BtnPressed = 0;
}

System.onScriptUnloading() {
	delete SongTickerTimer;
	delete callback;
}

callback.onTimer() {
	MuteBtnShade = getcontainer("main").getlayout("shade").findObject("shadeMute");
	SongTickerShade = getcontainer("main").getlayout("shade").findObject("songticker");
	if (MuteBtnShade != NULL) stop();
}

setTempText(String txt) {
	SongTickerTimer.start();
	Songticker.setAlternateText(txt);
	SongTickerShade.setAlternateText(txt);
}

SongTickerTimer.onTimer() {
  SongTicker.setText("");
  SongTickerShade.setText("");
  SongTickerTimer.stop();
}

MuteBtn.onLeftClick() {
	BtnPressed = 1;
	if (!Muted) {
		VolumeLevel = System.getVolume();
		System.setVolume(0);
		Muted = 1;
		setTempText("Mute ON");
		MuteBtnShade.setActivated(1);
	} else {
		System.setVolume(VolumeLevel);
		Muted = 0;
		setTempText("Mute OFF");
		MuteBtnShade.setActivated(0);
	}
}

MuteBtnShade.onLeftClick() {
	BtnPressed = 1;
	if (!Muted) {
		VolumeLevel = System.getVolume();
		System.setVolume(0);
		Muted = 1;
		setTempText("Mute ON");
		MuteBtn.setActivated(1);
	} else {
		System.setVolume(VolumeLevel);
		Muted = 0;
		setTempText("Mute OFF");
		MuteBtn.setActivated(0);
	}
}

System.onvolumechanged(int newvol) {
	//volumebar.setXmlParam("w",integertostring( (newvol/255) *70 + 5));
	if (!BtnPressed) {
		setTempText("Volume:" + System.integerToString(newvol / 255 * 100) + "%");

		if (Muted) {
			MuteBtn.setActivated(0);
			MuteBtnShade.setActivated(0);
			Muted = 0;
		}
	}
	BtnPressed = 0;
}
