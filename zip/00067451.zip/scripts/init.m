/*--------------------------------------------------------------------
 init script by Plague
 modded for StarTrek LCARS AMP PADD II
--------------------------------------------------------------------*/

#include <lib/std.mi>
#include "attribs.m"

Global Int attribs_mychange, attribs_mychange2;

#define NOOFF if (getData()=="0") { setData("1"); return; }

System.onScriptLoaded() {
  initAttribs();
}

myattr_alwaysOnTop.onDataChanged() {
  attr_aot.setData(myattr_alwaysOnTop.getData());
}

myattr_enableTooltips.onDataChanged() {
  attr_tooltips.setData(myattr_enableTooltips.getData());
}


myattr_dockWindows.onDataChanged() {
  attr_dockwindows.setData(myattr_dockWindows.getData());
}


attr_aot.onDataChanged() {
  String data = attr_aot.getData();
  if (data != myattr_alwaysOnTop.getData()) myattr_alwaysOnTop.setData(data);
}

attr_tooltips.onDataChanged() {
  String data = attr_tooltips.getData();
  if (data != myattr_enableTooltips.getData()) myattr_enableTooltips.setData(data);
}

attr_dockwindows.onDataChanged() {
  String data = attr_dockwindows.getData();
  if (data != myattr_dockWindows.getData()) myattr_dockWindows.setData(data);
}



myattr_notifierAlways.onDataChanged() {
  if (attribs_mychange) return;
  NOOFF
  attribs_mychange = 1;
  myattr_notifierNever.setData("0");
  myattr_notifierWindowshade.setData("0");
  myattr_notifierMinimized.setData("0");
  attribs_mychange = 0;
}

myattr_notifierNever.onDataChanged() {
  if (attribs_mychange) return;
  NOOFF
  attribs_mychange = 1;
  myattr_notifierAlways.setData("0");
  myattr_notifierWindowshade.setData("0");
  myattr_notifierMinimized.setData("0");
  attribs_mychange = 0;
}

myattr_notifierMinimized.onDataChanged() {
  if (attribs_mychange) return;
  NOOFF
  attribs_mychange = 1;
  myattr_notifierNever.setData("0");
  myattr_notifierWindowshade.setData("0");
  myattr_notifierAlways.setData("0");
  attribs_mychange = 0;
}

myattr_notifierWindowshade.onDataChanged() {
  if (attribs_mychange) return;
  NOOFF
  attribs_mychange = 1;
  myattr_notifierNever.setData("0");
  myattr_notifierAlways.setData("0");
  myattr_notifierMinimized.setData("0");
  attribs_mychange = 0;
}



myattr_notifierFadeEffect.onDataChanged() {
	if (attribs_mychange2) return;
	NOOFF
	attribs_mychange2 = 1;
	myattr_notifierSlideEffect.setData("0");
	attribs_mychange2 = 0;
}

myattr_notifierSlideEffect.onDataChanged() {
	if (attribs_mychange2) return;
	NOOFF
	attribs_mychange2 = 1;
	myattr_notifierFadeEffect.setData("0");
	attribs_mychange2 = 0;
}
