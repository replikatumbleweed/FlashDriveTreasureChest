/*--------------------------------------------------------------------
 Video/Normal player group script.
 Modified for Star Trek LCARS AMP PADD II
--------------------------------------------------------------------*/

#include "main_header.m" //Include the main_header Library


System.onScriptLoaded() {
	initAttribs();
	AutoRepeat_Load();  //This must be done in all scripts using the AutoRepeatButton library
	Group pgroup = getScriptGroup();

	// Get songticker, Volbar & Seeker
	Songticker = pgroup.findObject("Songticker");
	if (songticker == null) messagebox("ooch!!", "ooch", 0, "");
	Volbar = pgroup.findObject("Volume");
	Seeker = pgroup.findObject("Seeker");
	SeekGhost = pgroup.findObject("SeekerGhost");

	//autorepeatvolumebuttons
	VolumeUp = pgroup.getObject("VolumeUp");
	VolumeDown = pgroup.getObject("VolumeDown");
	CurrentVolume = System.GetVolume(); //start off out Current Volume var

	if (SeekGhost != NULL) SeekGhost.setAlpha(1);

	SongTickerTimer = new Timer;
	SongTickerTimer.setDelay(1000);

	ScrollTicker = stringToInteger(myattr_scrollSongticker.getData());
	if (!ScrollTicker) Songticker.setXmlParam("ticker", "0");
}
