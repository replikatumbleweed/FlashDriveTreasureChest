// checkbox control script, by Plague
// severely stripped down version of Will's original script

#include <lib/std.mi>

Global Text TxtBox;
Global ToggleButton ChkBox;

system.onscriptloaded() {
  TxtBox = getscriptgroup().findobject("checkbox.text"); // get the text from the xml
  ChkBox = getscriptgroup().findobject("checkbox.toggle"); // get the checkbox from the xml
}

System.onSetXuiParam(String param, String value) { // this is called when the params in <mycheckbox/> are set
  if(strlower(param)=="label") TxtBox.setText(value); // set the text of the textbox 
}

TxtBox.onLeftButtonDown(int x, int y) { // if the text is clicked, the togglebutton should toggle
  ChkBox.leftClick();
}
