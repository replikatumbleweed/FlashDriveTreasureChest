//-----------------------------------------------------------------------------
// Bassslider.m
//
// Example of a Bass Slider
// Has Simple and Advanced Modes controlled by a right-click menu
//
// created by FrisbeeMonkey
//-----------------------------------------------------------------------------

//                            USING THIS SCRIPT:
//*****************************************************************************
//  1.  Define the following in your XML:
//		  <Slider
//			id="BassSlider"
//			x="410" y="58"
//			w="36" h="93"
//			thumb="player.Thumb"
//			downThumb="player.ThumbDown"
//			orientation="vertical"
//		  />
//      Change the position(x,y) and size(w,h) of "BassSlider" to suit your
//		needs.
//  2.  Make sure your ticker is called "SongTicker" and is in the same group as
//      "BassSlider"  If you don't have a ticker, add one now.
//  3.  Copy this script (and BassSlider.maki) to your scripts folder.
//  4.  If you don't have BassSlider.maki, compile this script.
//  5.  Add this line to the group that contains your slider & songticker
//        <script id="BassSlider" file="scripts/BassSlider.maki"/>
//  6.  Refresh your skin(F5) and try it out.
//*****************************************************************************


// never forget to include std.mi
#include "../lib/std.mi"

//declares Bass functions
Function updateBass(int v);
Function setBassOnLayer(int bassValue, layer bassName);

//declares global variables
Global PopupMenu AdvMenu;
Global Slider Bass, bassg;
Global Timer SongTickerTimer;
Global Text SongTicker;
Global Int BassChanging, Advanced;
Global Layer bass_layer;
Global Map bassMap;

//when script is loaded, do this
System.onScriptLoaded() {

	// Get the group that has the objects we want
	Group pcGroup = getScriptGroup();

	// Now that we have the group, get the objects in the group
	Bass = pcGroup.findObject("BassSlider");
    //bassg = pcGroup.findObject("bass");
	SongTicker = pcGroup.findObject("songticker");
	bass_layer = pcGroup.findObject("bass_layer");

	bassMap = new Map;
	bassMap.loadMap("player.treble-bass.bar.map");

	// Initialize our timer
	SongTickerTimer = new Timer;
	SongTickerTimer.setDelay(750);

	float u = System.getEqBand(0) + 128;
	BassChanging = 0;
	Bass.setPosition(u);
	Advanced = getPrivateInt("BassSlider", "Advanced", 1);

	AdvMenu = new PopupMenu;
	AdvMenu.addCommand("Simple",1,0,0);
	AdvMenu.addCommand("Advanced",2,0,0);

}

// Clears text area
SongTickerTimer.onTimer() {
	SongTicker.setText("");
	SongTickerTimer.stop();
}

//right click menu for basic and advanced Bass control
Bass.onRightButtonUp(int x, int y) {
	AdvMenu.checkCommand(1,(!Advanced));
	AdvMenu.checkCommand(2,Advanced);

//pops up menu, returns choice
	int Choice = AdvMenu.popAtMouse();

	if (Choice == 1) { //Simple
		Advanced = 0;
	} else if (Choice == 2) { //Advanced
		Advanced = 1;
	}
	complete;//prevents system menu from showing
}

//handles clicks or drags on the Bass slider
Bass.onSetPosition(int newpos) {
    //bassg.setPosition(newpos);
	updateBass(newpos);
	setBassOnLayer(- (newpos), bass_layer);
}

Bass.onLeftButtonDown(int x, int y) {
	BassChanging = 1;
}

Bass.onLeftButtonUp(int x, int y) {
	BassChanging = 0;
}

// Updates Bass after drag/click
updateBass(float b) {
	if (BassChanging) {
	if (b >= 0) {
		float k = b / 255;
		if (Advanced) {
			if (b < 128) {
				if (b < 40) {
					System.setEqBand(0, -(128 - b));
					System.setEqBand(1, -(128 - b) +20);
					System.setEqBand(2, -(128 - b) +40);
					System.setEqBand(3, -(128 - b) +60);
					System.setEqBand(4, -(128 - b) +80);
				} else if (b < 60) {
					System.setEqBand(0, -(128 - b));
					System.setEqBand(1, -(128 - b) +20);
					System.setEqBand(2, -(128 - b) +40);
					System.setEqBand(3, -(128 - b) +60);
					System.setEqBand(4, 0);
				} else if (b < 80) {
					System.setEqBand(0, -(128 - b));
					System.setEqBand(1, -(128 - b) +20);
					System.setEqBand(2, -(128 - b) +40);
					System.setEqBand(3, 0);
					System.setEqBand(4, 0);
				} else if (b < 100) {
					System.setEqBand(0, -(128 - b));
					System.setEqBand(1, -(128 - b) +20);
					System.setEqBand(2, 0);
					System.setEqBand(3, 0);
					System.setEqBand(4, 0);
				} else {
					System.setEqBand(0, -(128 - b));
					System.setEqBand(1, 0);
					System.setEqBand(2, 0);
					System.setEqBand(3, 0);
					System.setEqBand(4, 0);
				}
			} else {
				if (b > 220) {
					System.setEqBand(0, -(128 - b));
					System.setEqBand(1, -(128 - b) -20);
					System.setEqBand(2, -(128 - b) -40);
					System.setEqBand(3, -(128 - b) -60);
					System.setEqBand(4, -(128 - b) -80);
				} else if (b > 200) {
					System.setEqBand(0, -(128 - b));
					System.setEqBand(1, -(128 - b) -20);
					System.setEqBand(2, -(128 - b) -40);
					System.setEqBand(3, -(128 - b) -60);
					System.setEqBand(4, 0);
				} else if (b > 180) {
					System.setEqBand(0, -(128 - b));
					System.setEqBand(1, -(128 - b) -20);
					System.setEqBand(2, -(128 - b) -40);
					System.setEqBand(3, 0);
					System.setEqBand(4, 0);
				} else if (b > 160) {
					System.setEqBand(0, -(128 - b));
					System.setEqBand(1, -(128 - b) -20);
					System.setEqBand(2, 0);
					System.setEqBand(3, 0);
					System.setEqBand(4, 0);
				} else {
					System.setEqBand(0, -(128 - b));
					System.setEqBand(1, 0);
					System.setEqBand(2, 0);
					System.setEqBand(3, 0);
					System.setEqBand(4, 0);
				}
				System.setEqBand(0, -(128 - b));
			}
		} else {
			for (int i=0; i<5; i++) {
				System.setEqBand(i, -(128 - b));
			}
		}
		int p = k * 100;
		SongTickerTimer.stop();
		SongTickerTimer.start();
		SongTicker.setText("Bass " + System.integerToString(p - 50) + "%");
	}
	}
}
// Reads System Bass Changes
System.onEqBandChanged(int band, int newvalue) {
	if (band == 0) {
		Float f = newvalue + 128;
			Bass.setPosition(f);
	}
}

//when Winamp closes or the skin is changed, delete objects and save settings
System.onScriptUnloading() {
	delete SongTickerTimer;
	delete AdvMenu;
	setPrivateInt("BassSlider", "Advanced", Advanced);
}

setBassOnLayer(int bassValue, layer bassName) {
  Region r = new Region;
  
  r.loadFromMap(bassMap, bassValue, 0);
  bassName.setRegion(r);
  
  delete r;
}
