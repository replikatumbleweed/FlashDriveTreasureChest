/////////////////////////////////////
// cycle_eq.m (Version 1.1)
//
// Cycles through the hardcoded "library" of equalizer presets and sets the eq bands through
// the use of two buttons (PrevEQPreset and NextEQPreset)
// [YES I wrote a script (not included) to extract those EXACT values from Winamp's EQ preset library]
//
// created by Jason Chiu - June 2004
//
//  NOTE:  I wish that their mc complier had support for
//       switch-case-statements and default-parameters like in C++
/////////////////////////////////////

///////////////////////////////////////
//  1.  Define the following in your XML:
/*
	<button id="PrevEQPreset"
		x="0" y="0" tooltip="Previous Equalizer Preset"
		image="eq.button.preset.prev"
		downImage="q.button.eq.preset.pressed"
		hoverImage="eq.button.eq.preset.hover"
	/>
	<button id="NextEQPreset"
		x="0" y="0" tooltip="Next Equalizer Preset"
		image="eq.button.preset.next"
		downImage="eq.button.preset.next.pressed"
		hoverImage="eq.button.preset.next.hover"
	/>
*/
//  2.  Copy this script to your scripts folder.
//  3.  If you don't have cycle_eq.maki, compile this script.
//  4.  Add this line to the group that contains the buttons you created in step 1
//        <script id="cycleEQ" file="scripts/cycle_eq.maki" />
//  5.  Refresh your skin (F5) and try it out.
/////////////////////////////////////////

#include "../lib/std.mi"

Function String setEqPreset(int currentPreset);
Function setEqPresetBands(int preamp, int band0, int band1, int band2, int band3, int band4, int band5, int band6, int band7, int band8, int band9);

//declare global variables
Global Button PrevEQPreset, NextEQPreset;
Global Group pcGroup;
Global Timer SongTickerTimer;
Global Text SongTicker;
Global Int currentPreset;
#define MIN_CURRENT_PRESET 0
#define MAX_CURRENT_PRESET 17

//init on script load
System.onScriptLoaded() {
	pcGroup = getScriptGroup();
	PrevEQPreset = pcGroup.findObject("PrevEQPreset");
	NextEQPreset = pcGroup.findObject("NextEQPreset");
	SongTicker = pcGroup.findObject("songticker");

	SongTickerTimer = new Timer;
	SongTickerTimer.setDelay(750);
	currentPreset = 0; //Default; all bands are at zero
}

// Clears text area
SongTickerTimer.onTimer() {
	SongTicker.setText("");
	SongTickerTimer.stop();
}

PrevEQPreset.onLeftButtonUp(int x, int y) {
	if (PrevEQPreset.isMouseOver(x, y)) {  //make sure mouse is released over button
		currentPreset--;
		if (currentPreset < MIN_CURRENT_PRESET) currentPreset = MAX_CURRENT_PRESET;
		SongTickerTimer.stop();
		SongTickerTimer.start();
		SongTicker.setText( setEqPreset(currentPreset) );
	}
}

NextEQPreset.onLeftButtonUp(int x, int y) {
	if (NextEQPreset.isMouseOver(x, y)) {  //make sure mouse is released over button
		currentPreset++;
		if (currentPreset > MAX_CURRENT_PRESET) currentPreset = MIN_CURRENT_PRESET;
		SongTickerTimer.stop();
		SongTickerTimer.start();
		SongTicker.setText( setEqPreset(currentPreset) );
	}
}


//Preamp range is from -127 to +127 (0 means no preamp)
//EqBands are numbered from 0 (60Hz) to 9 (16kHz)
String setEqPreset(int currentPreset) {
	if (currentPreset == MIN_CURRENT_PRESET) {
			setEqPresetBands(0,0,0,0,0,0,0,0,0,0,0);
			return "Default";
	} else if (currentPreset == 1) {
			setEqPresetBands(1,1,1,1,1,1,1,-51,-51,-51,-67);
			return "Classical";
	} else if (currentPreset == 2) {
			setEqPresetBands(1,1,1,21,37,37,37,21,1,1,1);
			return "Club";
	} else if (currentPreset == 3) {
			setEqPresetBands(1,61,45,13,0,0,-43,-51,-51,0,0);
			return "Dance";
	} else if (currentPreset == 4) {
			setEqPresetBands(1,61,61,61,37,9,-31,-59,-71,-75,-75);
			return "Full Bass";
	} else if (currentPreset == 5) {
			setEqPresetBands(1,45,37,1,-51,-35,9,53,69,77,77);
			return "Full Bass & Treble";
	} else if (currentPreset == 6) {
			setEqPresetBands(1,-67,-67,-67,-31,17,69,101,101,101,109);
			return "Full Treble";
	} else if (currentPreset == 7) {
			setEqPresetBands(1,29,69,33,-27,-19,9,29,61,81,93);
			return "Laptop Speakers/Headphones";
	} else if (currentPreset == 8) {
			setEqPresetBands(1,65,65,37,37,1,-35,-35,-35,1,1);
			return "Large Hall";
	} else if (currentPreset == 9) {
			setEqPresetBands(1,-35,1,25,33,37,37,25,17,17,13);
			return "Live";
	} else if (currentPreset == 10) {
			setEqPresetBands(1,45,45,1,1,1,1,1,1,45,45);
			return "Party";
	} else if (currentPreset == 11) {
			setEqPresetBands(1,-15,29,45,49,33,-11,-19,-19,-15,-15);
			return "Pop";
	} else if (currentPreset == 12) {
			setEqPresetBands(1,1,1,-7,-43,1,41,41,1,1,1);
			return "Reggae";
	} else if (currentPreset == 13) {
			setEqPresetBands(1,49,29,-39,-55,-27,25,57,69,69,69);
			return "Rock";
	} else if (currentPreset == 14) {
			setEqPresetBands(1,-19,-35,-31,-7,25,37,57,61,69,61);
			return "Ska";
	} else if (currentPreset == 15) {
			setEqPresetBands(1,29,9,-11,-19,-11,25,53,61,69,77);
			return "Soft";
	} else if (currentPreset == 16) {
			setEqPresetBands(1,25,25,13,-7,-31,-39,-27,-7,17,57);
			return "Soft Rock";
	} else if (currentPreset == MAX_CURRENT_PRESET) {
			setEqPresetBands(1,49,37,1,-39,-35,1,49,61,61,57);
			return "Techno";
	} else {
			currentPreset = 0;
			setEqPresetBands(0,0,0,0,0,0,0,0,0,0,0);
			return "Default";
	}
}

setEqPresetBands(int preamp, int band0, int band1, int band2, int band3, int band4, int band5, int band6, int band7, int band8, int band9) {
	System.setEqPreamp(preamp);
	System.setEqBand(0, band0);
	System.setEqBand(1, band1);
	System.setEqBand(2, band2);
	System.setEqBand(3, band3);
	System.setEqBand(4, band4);
	System.setEqBand(5, band5);
	System.setEqBand(6, band6);
	System.setEqBand(7, band7);
	System.setEqBand(8, band8);
	System.setEqBand(9, band9);
	return;
}
