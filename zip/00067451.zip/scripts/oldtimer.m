// ****************************
// **    Old Winamp timer    **
// ****************************
// by ThePlague
// - brings back the old Winamp
//   timer [00:00] instead of
//   the new one [0:00]
// - NO xml changes needed!!
// - even links normal and
//   shade timers!
//
//   Updated by FrisbeeMonkey
//   for greater flexibility

////////////////////////////////////////////////////////////
//	WARNING:  Modified by JCOnline for StarTrek LCARS AMP PADD II

#include <lib/std.mi>

Function String oldTimer(int CurPos);

Global Timer tmrWait;
Global Text txtTimer, txtTimerShade, txtTimerCompact;
Global Boolean MinusIsOn;

System.onScriptLoaded() {
  Group mainshade = getContainer("Main").getLayout("Shade");
  txtTimerShade = mainshade.findObject("timer");

  Group mainnormal = getContainer("Main").getLayout("Normal");
  txtTimer = mainnormal.findObject("timer");
  
  Group maincompact = getContainer("Main").getLayout("Compact");
  txtTimerCompact = maincompact.findObject("timer"); 

  tmrWait = new Timer;
  tmrWait.setDelay(20);

  MinusIsOn = getPrivateInt("Settings", "Minus", 0);

  if (System.getStatus()==1) tmrWait.start();
}

System.onScriptUnloading() {
  tmrWait.stop();
  delete tmrWait;
}

System.onPlay() {
  tmrWait.start();
}

System.onStop() {
  tmrWait.stop();
  txtTimer.setText("");
  txtTimerShade.setText("");
  txtTimerCompact.setText("");
}

tmrWait.onTimer() {
  if (MinusIsOn) txtTimer.setText(oldTimer(getPlayItemLength()-getPosition()));
  else txtTimer.setText(oldTimer(getPosition()));

  if (MinusIsOn) txtTimerShade.setText(oldTimer(getPlayItemLength()-getPosition()));
  else txtTimerShade.setText(oldTimer(getPosition()));

  if (MinusIsOn) txtTimerCompact.setText(oldTimer(getPlayItemLength()-getPosition()));
  else txtTimerCompact.setText(oldTimer(getPosition()));
}

txtTimer.onLeftButtonDown(int x, int y) {
  if (MinusIsOn) MinusIsOn=0;
  else MinusIsOn=1;
  setPrivateInt("Settings","Minus", MinusIsOn);
}

txtTimerShade.onLeftButtonDown(int x, int y) {
  if (MinusIsOn) MinusIsOn=0;
  else MinusIsOn=1;
  setPrivateInt("Settings","Minus", MinusIsOn);
}

txtTimerCompact.onLeftButtonDown(int x, int y) {
  if (MinusIsOn) MinusIsOn=0;
  else MinusIsOn=1;
  setPrivateInt("Settings","Minus", MinusIsOn);
}

String oldTimer(int CurPos) {
  String SpecTmr = integerToTime(CurPos);
  String Temp = integerToString(CurPos);
  int TempLen = strlen(Temp);

  if (strlen(SpecTmr)==4) SpecTmr = "0" + SpecTmr;

  if (MinusIsOn) SpecTmr = "-" + SpecTmr;
  else SpecTmr = " " + SpecTmr;

  return SpecTmr;
}
