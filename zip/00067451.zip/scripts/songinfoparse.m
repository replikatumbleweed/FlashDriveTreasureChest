//originally by Gonzotek
//updated by ThePlague
//- added Willfishers startup fix and modified the original code for that fix
//- fixed Frequency when playing .ogg files (they write kHz in lowercase, khz, which would make this script not find that info)

#include <lib/std.mi>

Function String tokenizeSongInfo(String tkn, String sinfo);

//Global GuiObject mono, stereo;
Global Text bitrateText, infolineText, channelsText, FrequencyText, abrText;
//Global Layout Main;
Global String SongInfoString;

System.onScriptLoaded() {
	//Main = getContainer("main").getLayout("normal");
	Group Main = getScriptGroup();
	
	//mono = Main.getObject("mono-led-on");
	//stereo = Main.getObject("stereo-led-on");
	infolineText = Main.getObject("infoline");
	bitrateText = Main.getObject("Bitrate");
	abrText = Main.getObject("ABR");
	channelsText = Main.getObject("Channels");
	frequencyText = Main.getObject("Frequency");
	infolineText.setText("-");
	infolineText.setText("");
	/*if(System.getStatus() == 0){
		mono.hide();
		stereo.hide();
	}*/
}

System.onStop(){
	frequencyText.setText("");
	bitrateText.setText("");
	channelsText.setText("");
	//mono.hide();
	//stereo.hide();
}

infolineText.onTextChanged(string newtxt) {
if(newtxt == "-") return;
String tkn;
int searchResult;
	SongInfoString = newtxt;

	tkn = tokenizeSongInfo("Bitrate", SongInfoString);
	if(tkn!="") bitrateText.setText(tkn);

	tkn = tokenizeSongInfo("ABR", SongInfoString);
	if(tkn!="") abrText.setText(tkn);

	tkn = tokenizeSongInfo("Channels", SongInfoString);
	if(tkn!="") channelsText.setText(tkn);

	tkn = tokenizeSongInfo("Frequency", SongInfoString);
	if(tkn!="") frequencyText.setText(tkn);
}

tokenizeSongInfo(String tkn, String sinfo){
int searchResult;
String rtn;
if (tkn=="Bitrate"){
  for (int i = 0; i < 5; i++) {
    rtn = getToken(strlower(sinfo), " ", i);
    searchResult = strsearch(rtn, "kbps");
    if (searchResult > 0) {
      rtn = Strleft(rtn, searchResult);
      searchResult = strsearch(rtn, ".");
      if (searchResult > 0) rtn = Strleft(rtn, searchResult);
      if (strlen(rtn) == 1) rtn = "  " + rtn;
      else if (strlen(rtn) == 2) rtn = " " + rtn;
      return rtn;
    }
  }
  return "";
}
if (tkn=="Channels"){
		for (int i = 0; i < 5; i++) {
			rtn = getToken(sinfo, " ", i);
			searchResult = strsearch(rtn, "tereo");
			//stereo.show();
			//mono.hide();
			if (searchResult>0) return rtn;
			searchResult = strsearch(rtn, "ono");
			//mono.show();
			//stereo.hide();
			if (searchResult>0) return rtn;
		}
		return "";
}
if (tkn=="Frequency"){
		for (int i = 0; i < 5; i++) {
			rtn = getToken(sinfo, " ", i);
			searchResult = strsearch(strlower(rtn), "khz");
			if (searchResult>0) return Strleft(rtn, 2);
		}
		return "";
}
if (tkn=="ABR"){
		for (int i = 0; i < 5; i++) {
			rtn = getToken(sinfo, " ", i);
			searchResult = strsearch(rtn, "bps)");
			if (searchResult>0) return rtn;
		}
		return "";
}


else return "";
}