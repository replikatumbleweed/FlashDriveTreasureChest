/*--------------------------------------------------------------------
 Main/Normal player group script.
 Modified for Star Trek LCARS AMP PADD II (its songticker is not in the play buttons group)
--------------------------------------------------------------------*/

#include "main_header.m" //Include the main_header Library

Class Button HintObject;
Global HintObject Thinger, Eq, Ml, Pl, Ct;

System.onScriptLoaded() {
	initAttribs();
	AutoRepeat_Load();  //This must be done in all scripts using the AutoRepeatButton library
	Group pgroup = getScriptGroup();

	// Get songticker, Volbar & Seeker
	Songticker = pgroup.findObject("Songticker");
	if (songticker == null) messagebox("ooch!!", "ooch", 0, "");
	Volbar = pgroup.findObject("Volume");
	Seeker = pgroup.findObject("Seeker");
	SeekGhost = pgroup.findObject("SeekerGhost");

	// Get Various buttons
	RepeatBtn = pgroup.findObject("Repeat");
	ShuffleBtn = pgroup.findObject("Shuffle");
	CrossfadeBtn = pgroup.findObject("Crossfade");

	Thinger = pgroup.findObject("th");
	Eq = pgroup.findObject("eql");
	Ml = pgroup.findObject("ml");
	Pl = pgroup.findObject("pl");
	Ct = pgroup.findObject("ct");

	//autorepeatvolumebuttons
	VolumeUp = pgroup.getObject("VolumeUp");
	VolumeDown = pgroup.getObject("VolumeDown");
	CurrentVolume = System.GetVolume(); //start off out Current Volume var

	Rew5s = pgroup.findObject("Rew5s");
	Fwd5s = pgroup.findObject("Fwd5s");

	if (SeekGhost != NULL) SeekGhost.setAlpha(1);

	SongTickerTimer = new Timer;
	SongTickerTimer.setDelay(1000);

	ScrollTicker = stringToInteger(myattr_scrollSongticker.getData());
	if (!ScrollTicker) Songticker.setXmlParam("ticker", "0");
}

HintObject.onLeftClick() {
	if (HintObject == Pl) setTempText("Playlist Editor");
	else if (HintObject == Ml) setTempText("Media Library");
	else if (HintObject == Thinger) setTempText("Config");
	else if (HintObject == Eq) setTempText("Equalizer");
	else if (HintObject == Eq) setTempText("Equalizer");
	else if (HintObject == Ct) setTempText("Gamma Presets");
}
