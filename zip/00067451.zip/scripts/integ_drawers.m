/*-----------------------------------------------------------------------------
 drawer.m
 by Jason Chiu
 based on drawer.m by FrisbeeMonkey (www.frisbeemonkey.com)
 GOTO www.frisbeemonkey.com to get the ORIGINAL maki script.
 -----------------------------------------------------------------------------*/

#include "drawer.m" //Include the Drawer Library

Global Layer LCARS_Label;

//when the script is loaded, do this
System.onScriptLoaded() {
	initAttribs();
	//gets the group that has the objects we want
	normal = system.getContainer("main").getLayout("normal");

	THonScreenGroup = normal.findObject("config_drawer");
	THbtnLocation = normal.findObject("player.normal.playbuttons");
	CTonScreenGroup = normal.findObject("colortheme_drawer");
	CTbtnLocation = normal.findObject("player.normal.playbuttons");
	EQonScreenGroup = normal.findObject("eqdrawer");
	EQbtnLocation = normal.findObject("player.normal.playbuttons");	
	Main_draweronScreenGroup = normal.findObject("Main_drawer");
	Main_drawerbtnLocation = normal.findObject("player.normal.playbuttons");	

	InitVars();

	LCARS_Label = normal.findObject("player.main.lcars_label");
	if (AnimateDrawer) LCARS_Label.setAlpha(0);
	else LCARS_Label.setAlpha(255);
	
	LCARS_Label.hide();

}//end onScriptLoaded()

myattr_animateDrawer.onDataChanged() {
	AnimateDrawer = stringToInteger(myattr_animateDrawer.getData());
	if (AnimateDrawer && DrawerOut) {
		THonScreenGroup.setAlpha(255);
		CTonScreenGroup.setAlpha(255);
		EQonScreenGroup.setAlpha(255);
		LCARS_Label.setAlpha(255);
	} else {
		THonScreenGroup.setAlpha(255);
		CTonScreenGroup.setAlpha(255);
		EQonScreenGroup.setAlpha(255);
		LCARS_Label.setAlpha(255);
	}
}

/***** Open and Close Operations *******/
//Open and Close Main_drawerDrawer Functions
Main_drawerDrawerOpen() {  // if our Drawer is closed, make it slide open
	//if (!Main_draweronScreenGroup.isGoingToTarget()) {  //makes sure it isn't already moving
		DrawerOut = 1;  //Change the flag to Open

	   	LCARS_Label.show();

		if (AnimateDrawer) {
			Main_draweronScreenGroup.setTargetX(Main_drawerEndX);  //set the x coordinate you want the drawer to slide to
			Main_draweronScreenGroup.setTargetY(Main_drawerEndY);  //set the y coordinate you want the drawer to slide to
			Main_draweronScreenGroup.setTargetSpeed(1);  //sets the speed the drawer will slide at(higher is slower)
			Main_draweronScreenGroup.gotoTarget();  //now that we have our target values and speed, start moving!
			normal.beforeRedock();
			normal.setXmlParam("snapadjustbottom", "0");
			normal.redock();
		} else {
			normal.beforeRedock();
			normal.setXmlParam("snapadjustbottom", "0");
			Main_draweronScreenGroup.setXmlParam("y", integerToString(Main_drawerEndY) );
			Main_draweronScreenGroup.setXmlParam("x", integerToString(Main_drawerEndX) );
			normal.redock();
		}
	//}
}

Main_drawerDrawerClose() {  // if our Drawer is open, make it slide closed
	//if (!Main_draweronScreenGroup.isGoingToTarget()) {  //makes sure it isn't already moving
		DrawerOut = 0;  //Change the flag to Closed

		if (AnimateDrawer) {
			LCARS_Label.setTargetA(0);
			LCARS_Label.setTargetSpeed(1);
			LCARS_Label.gotoTarget();
		}
		LCARS_Label.hide();

		normal.beforeRedock();
		if (AnimateDrawer) {
			Main_draweronScreenGroup.setTargetX(Main_drawerStartX);  //set the x coordinate you want the drawer to slide back to
			Main_draweronScreenGroup.setTargetY(Main_drawerStartY);   //set the y coordinate you want the drawer to slide back to
			Main_draweronScreenGroup.setTargetSpeed(1);  //sets the speed the drawer will slide at(higher is slower)
			Main_draweronScreenGroup.gotoTarget();  //now that we have our target values and speed, start moving!
			normal.beforeRedock();
			normal.setXmlParam("snapadjustbottom", "120");
			normal.redock();
		} else {
			normal.beforeRedock();
			normal.setXmlParam("snapadjustbottom", "120");
			Main_draweronScreenGroup.setXmlParam("y", integerToString(Main_drawerStartY) );
			Main_draweronScreenGroup.setXmlParam("x", integerToString(Main_drawerStartX) );
			normal.redock();
		}
	//}
}

Main_draweronScreenGroup.onTargetReached() {
	if (DrawerOut) {
    	LCARS_Label.show();
		if (AnimateDrawer) {
			LCARS_Label.setTargetA(255);
			LCARS_Label.setTargetSpeed(1);
			LCARS_Label.gotoTarget();
		}
	}
}
