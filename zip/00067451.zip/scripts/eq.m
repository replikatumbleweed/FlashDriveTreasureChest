//-----------------------------------------------------------------------------
// eqbyregion.m
//
// Example of Animated EQ bars using Regions
//
// written by FrisbeeMonkey
//-----------------------------------------------------------------------------

//                            USING THIS SCRIPT:
//*****************************************************************************
//  1.  Define the following in your XML:
//	<layer id="EQPreamp" image="player.EQBar" x="?" y="?"/>
//
//	<layer id="EQBar?" image="player.EQBar" x="?" y="?"/>
//      Change the position(x,y) to the specifics of your layers.
//      For the EQBars, you should have 10 of them, EQBar0 to EQBar9
//  2.  Define your gradient maps with your other elements using:
//        <bitmap id="player.EQBarMap" file="player/player-map-eqbar.png"/>
//      If you need help creating a map file, check:
//        http://www.stefanweb.com/wa3/tutorials.html#UsingMaps
//  3.  Copy this script (and eqbyregion.maki) to your scripts folder.
//  5.  If you don't have eqbyregion.maki, compile this script.
//  6.  Add this line to the group that contains your layer and SongTicker
//        <script id="eqanim" file="scripts/eqbyregion.maki"/>
//  7.  Refresh your skin(F5) and try it out.
//*****************************************************************************

// Never forget to include std.mi
#include </lib/std.mi>

Function setEqOnLayer(int eqValue, layer eqName);

Global Layer eqpre,eq0,eq1,eq2,eq3,eq4,eq5,eq6,eq7,eq8,eq9;

Global Map eqMap;

System.onScriptLoaded() {
 //Layout eqLayout = system.getContainer("main").getLayout("normal");
 //Group groupDrawer = eqLayout.findObject("eqdrawer");

//  eqpre = groupDrawer.getObject("eqpre");
//  eq0 = groupDrawer.getObject("eq0");
//  eq1 = groupDrawer.getObject("eq1");
//  eq2 = groupDrawer.getObject("eq2");
//  eq3 = groupDrawer.getObject("eq3");
//  eq4 = groupDrawer.getObject("eq4");
//  eq5 = groupDrawer.getObject("eq5");
//  eq6 = groupDrawer.getObject("eq6");
//  eq7 = groupDrawer.getObject("eq7");
//  eq8 = groupDrawer.getObject("eq8");
//  eq9 = groupDrawer.getObject("eq9");

	Group pgroup = getScriptGroup();
	  
  eqpre = pgroup.findObject("eqpre");
  eq0 = pgroup.findObject("eq0");
  eq1 = pgroup.findObject("eq1");
  eq2 = pgroup.findObject("eq2");
  eq3 = pgroup.findObject("eq3");
  eq4 = pgroup.findObject("eq4");
  eq5 = pgroup.findObject("eq5");
  eq6 = pgroup.findObject("eq6");
  eq7 = pgroup.findObject("eq7");
  eq8 = pgroup.findObject("eq8");
  eq9 = pgroup.findObject("eq9");

  EQMap = new Map;
  EQMap.loadMap("player.eq.bar.map");

  setEqOnLayer(- (System.getEqPreamp()) + 128, eqpre);
  setEqOnLayer(- (System.getEqBand(1)) + 128, eq0);
  setEqOnLayer(- (System.getEqBand(2)) + 128, eq1);
  setEqOnLayer(- (System.getEqBand(3)) + 128, eq2);
  setEqOnLayer(- (System.getEqBand(4)) + 128, eq3);
  setEqOnLayer(- (System.getEqBand(5)) + 128, eq4);
  setEqOnLayer(- (System.getEqBand(6)) + 128, eq5);
  setEqOnLayer(- (System.getEqBand(7)) + 128, eq6);
  setEqOnLayer(- (System.getEqBand(8)) + 128, eq7);
  setEqOnLayer(- (System.getEqBand(9)) + 128, eq8);
  setEqOnLayer(- (System.getEqBand(10)) + 128, eq9);

}

System.onEqPreampChanged(int newvalue) {
 setEqOnLayer(- (newvalue) + 128, eqpre);
}

System.onEqBandChanged(int band, int newvalue) {
 if (band == 0) setEqOnLayer(- (newvalue) + 128, eq0);
 if (band == 1) setEqOnLayer(- (newvalue) + 128, eq1);
 if (band == 2) setEqOnLayer(- (newvalue) + 128, eq2);
 if (band == 3) setEqOnLayer(- (newvalue) + 128, eq3);
 if (band == 4) setEqOnLayer(- (newvalue) + 128, eq4);
 if (band == 5) setEqOnLayer(- (newvalue) + 128, eq5);
 if (band == 6) setEqOnLayer(- (newvalue) + 128, eq6);
 if (band == 7) setEqOnLayer(- (newvalue) + 128, eq7);
 if (band == 8) setEqOnLayer(- (newvalue) + 128, eq8);
 if (band == 9) setEqOnLayer(- (newvalue) + 128, eq9);
}

setEqOnLayer(int eqValue, layer eqName) {
  Region r = new Region;
  
  r.loadFromMap(EQMap, eqValue, 0);
  eqName.setRegion(r);
  
  delete r;
}