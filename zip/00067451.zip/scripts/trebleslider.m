//-----------------------------------------------------------------------------
// Trebleslider.m
//
// Example of a Treble Slider
// Has Simple and Advanced Modes controlled by a right-click menu
//
// created by FrisbeeMonkey
//-----------------------------------------------------------------------------

//                            USING THIS SCRIPT:
//*****************************************************************************
//  1.  Define the following in your XML:
//		  <Slider
//			id="TrebleSlider"
//			x="410" y="58"
//			w="36" h="93"
//			thumb="player.Thumb"
//			downThumb="player.ThumbDown"
//			orientation="vertical"
//		  />
//      Change the position(x,y) and size(w,h) of "TrebleSlider" to suit your
//		needs.
//  2.  Make sure your ticker is called "SongTicker" and is in the same group as
//      "TrebleSlider"  If you don't have a ticker, add one now.
//  3.  Copy this script (and TrebleSlider.maki) to your scripts folder.
//  4.  If you don't have TrebleSlider.maki, compile this script.
//  5.  Add this line to the group that contains your slider & songticker
//        <script id="TrebleSlider" file="scripts/TrebleSlider.maki"/>
//  6.  Refresh your skin(F5) and try it out.
//*****************************************************************************


// never forget to include std.mi
#include "../lib/std.mi"

//declares Treble functions
Function updateTreble(int v);
Function setTrebleOnLayer(int trebleValue, layer trebleName);

//declares global variables
Global PopupMenu AdvMenu;
Global Slider Treble, trebleg;
Global Timer SongTickerTimer;
Global Text SongTicker;
Global Int TrebleChanging, Advanced;
Global Layer treble_layer;
Global Map trebleMap;

//when script is loaded, do this
System.onScriptLoaded() {

	// Get the group that has the objects we want
	Group pcGroup = getScriptGroup();

	// Now that we have the group, get the objects in the group
	Treble = pcGroup.findObject("TrebleSlider");
    //trebleg = pcGroup.findObject("treble");
	SongTicker = pcGroup.findObject("songticker");
	treble_layer = pcGroup.findObject("treble_layer");

	trebleMap = new Map;
	trebleMap.loadMap("player.treble-bass.bar.map");

	// Initialize our timer
	SongTickerTimer = new Timer;
	SongTickerTimer.setDelay(750);

	TrebleChanging = 0;
	float u = System.getEqBand(9) + 128;
	Treble.setPosition(u);
	Advanced = getPrivateInt("TrebleSlider", "Advanced", 1);

	AdvMenu = new PopupMenu;
	AdvMenu.addCommand("Simple",1,0,0);
	AdvMenu.addCommand("Advanced",2,0,0);

}

// Clears text area
SongTickerTimer.onTimer() {
	SongTicker.setText("");
	SongTickerTimer.stop();
}

//right click menu for basic and advanced treble control
Treble.onRightButtonUp(int x, int y) {
	AdvMenu.checkCommand(1,(!Advanced));
	AdvMenu.checkCommand(2,Advanced);
	
//pops up menu, returns choice
	int Choice = AdvMenu.popAtMouse();
	
	if (Choice == 1) { //Simple
		Advanced = 0;
	} else if (Choice == 2) { //Advanced
		Advanced = 1;
	}
	complete;//prevents system menu from showing
}

//handles clicks or drags on the treble slider
Treble.onSetPosition(int newpos) {
    //trebleg.setPosition(newpos);
	updateTreble(newpos);
	setTrebleOnLayer(- (newpos), treble_layer);
}

Treble.onLeftButtonDown(int x, int y) {
	TrebleChanging = 1;
}

Treble.onLeftButtonUp(int x, int y) {
	TrebleChanging = 0;
}

// Updates Treble after drag/click
updateTreble(float b) {
	if (TrebleChanging) {
	if (b >= 0) {
		float k = b / 255;
		if (Advanced) {
			if (b < 128) {
				if (b < 40) {
					System.setEqBand(9, -(128 - b));
					System.setEqBand(8, -(128 - b) +20);
					System.setEqBand(7, -(128 - b) +40);
					System.setEqBand(6, -(128 - b) +60);
					System.setEqBand(5, -(128 - b) +80);
				} else if (b < 60) {
					System.setEqBand(9, -(128 - b));
					System.setEqBand(8, -(128 - b) +20);
					System.setEqBand(7, -(128 - b) +40);
					System.setEqBand(6, -(128 - b) +60);
					System.setEqBand(5, 0);
				} else if (b < 80) {
					System.setEqBand(9, -(128 - b));
					System.setEqBand(8, -(128 - b) +20);
					System.setEqBand(7, -(128 - b) +40);
					System.setEqBand(6, 0);
					System.setEqBand(5, 0);
				} else if (b < 100) {
					System.setEqBand(9, -(128 - b));
					System.setEqBand(8, -(128 - b) +20);
					System.setEqBand(7, 0);
					System.setEqBand(6, 0);
					System.setEqBand(5, 0);
				} else {
					System.setEqBand(9, -(128 - b));
					System.setEqBand(8, 0);
					System.setEqBand(7, 0);
					System.setEqBand(6, 0);
					System.setEqBand(5, 0);
				}
			} else {
				if (b > 220) {
					System.setEqBand(9, -(128 - b));
					System.setEqBand(8, -(128 - b) -20);
					System.setEqBand(7, -(128 - b) -40);
					System.setEqBand(6, -(128 - b) -60);
					System.setEqBand(5, -(128 - b) -80);
				} else if (b > 200) {
					System.setEqBand(9, -(128 - b));
					System.setEqBand(8, -(128 - b) -20);
					System.setEqBand(7, -(128 - b) -40);
					System.setEqBand(6, -(128 - b) -60);
					System.setEqBand(5, 0);
				} else if (b > 180) {
					System.setEqBand(9, -(128 - b));
					System.setEqBand(8, -(128 - b) -20);
					System.setEqBand(7, -(128 - b) -40);
					System.setEqBand(6, 0);
					System.setEqBand(5, 0);
				} else if (b > 160) {
					System.setEqBand(9, -(128 - b));
					System.setEqBand(8, -(128 - b) -20);
					System.setEqBand(7, 0);
					System.setEqBand(6, 0);
					System.setEqBand(5, 0);
				} else {
					System.setEqBand(9, -(128 - b));
					System.setEqBand(8, 0);
					System.setEqBand(7, 0);
					System.setEqBand(6, 0);
					System.setEqBand(5, 0);
				}

			}
		} else {
			for (int i=5; i<10; i++) {
				System.setEqBand(i, -(128 - b));
			}
		}
		int p = k * 100;
		SongTickerTimer.stop();
		SongTickerTimer.start();
		SongTicker.setText("Treble " + System.integerToString(p - 50) + "%");
	}
}
}

// Reads System Treble Changes
System.onEqBandChanged(int band, int newvalue) {
	if (band == 9) {
		Float f = newvalue + 128;
			Treble.setPosition(f);
	}
}

//when Winamp closes or the skin is changed, delete objects and save settings
System.onScriptUnloading() {
	delete SongTickerTimer;
	delete AdvMenu;
	setPrivateInt("TrebleSlider", "Advanced", Advanced);
}

setTrebleOnLayer(int trebleValue, layer trebleName) {
  Region r = new Region;
  
  r.loadFromMap(trebleMap, trebleValue, 0);
  trebleName.setRegion(r);
  
  delete r;
}
