#ifndef WINAMP5
#define WINAMP5
#endif
