/*

  Copyright (c) 2003-2004 Linus Brolin.

    This software is provided 'as-is', without any express or implied
    warranty.  In no event will the authors be held liable for any damages
    arising from the use of this software.

    Permission is granted to anyone to use this software for any purpose,
    including commercial applications, and to alter it and redistribute it
    freely, subject to the following restrictions:

    1. The origin of this software must not be misrepresented; you must not
       claim that you wrote the original software. If you use this software
       in a product, an acknowledgment in the product documentation would be
       appreciated but is not required.
    2. Altered source versions must be plainly marked as such, and must not be
       misrepresented as being the original software.
    3. This notice may not be removed or altered from any source distribution.


  Linus Brolin
  linus.b@home.se

*/

/*-----------------------------------------------------------------------------
  about.m

  by Plague (Linus Brolin)
-----------------------------------------------------------------------------*/

#include <lib/std.mi>

Global Text text1, text1a, text2, text2a, text3, text3a, text4, text4a;
Global Int line;
Global String version, month, day, year;
Global Timer timer1;

System.onScriptUnloading() {
  timer1.stop();
  delete timer1;
}

System.onScriptLoaded() {
  Group pgroup = getScriptGroup();
  text1 = pgroup.findObject("text1");
  text1a = pgroup.findObject("text1a");
  text2 = pgroup.findObject("text2");
  text2a = pgroup.findObject("text2a");
  text3 = pgroup.findObject("text3");
  text3a = pgroup.findObject("text3a");
  text4 = pgroup.findObject("text4");
  text4a = pgroup.findObject("text4a");

  timer1 = new Timer;
  timer1.setDelay(1000);

  String param = getParam();
  version = getToken(param, ",", 0);
  month = getToken(param, ",", 1);
  day = getToken(param, ",", 2);
  year = getToken(param, ",", 3);

  text1.setAlpha(0);
  text1a.setAlpha(0);
  text2.setAlpha(0);
  text2a.setAlpha(0);
  text3.setAlpha(0);
  text3a.setAlpha(0);
  text4.setAlpha(0);
  text4a.setAlpha(0);
  text1.setText("StarTrek LCARS AMP PADD II for Winamp");
  text2.setText("Created by Jason Chiu");
  line = 2;

  text1.setTargetA(255);
  text1.setTargetSpeed(2);
  text2.setTargetA(255);
  text2.setTargetSpeed(2);
  text1.gotoTarget();
  text2.gotoTarget();
}

timer1.onTimer() {
  timer1.stop();

  if (text1.getAlpha() > 250) {
    text1.setTargetA(0);
    text1.setTargetSpeed(2);
    text1.gotoTarget();
  }
  if (text1a.getAlpha() > 250) {
    text1a.setTargetA(0);
    text1a.setTargetSpeed(2);
    text1a.gotoTarget();
  }
  if (text2.getAlpha() > 250) {
    text2.setTargetA(0);
    text2.setTargetSpeed(2);
    text2.gotoTarget();
  }
  if (text2a.getAlpha() > 250) {
    text2a.setTargetA(0);
    text2a.setTargetSpeed(2);
    text2a.gotoTarget();
  }
  if (text3.getAlpha() > 250) {
    text3.setTargetA(0);
    text3.setTargetSpeed(2);
    text3.gotoTarget();
  }
  if (text3a.getAlpha() > 250) {
    text3a.setTargetA(0);
    text3a.setTargetSpeed(2);
    text3a.gotoTarget();
  }
  if (text4.getAlpha() > 250) {
    text4.setTargetA(0);
    text4.setTargetSpeed(2);
    text4.gotoTarget();
  }
  if (text4a.getAlpha() > 250) {
    text4a.setTargetA(0);
    text4a.setTargetSpeed(2);
    text4a.gotoTarget();
  }

  if (line == 1) {
    text1.setText("StarTrek LCARS AMP PADD II for Winamp");
    text1.setTargetA(255);
    text1.setTargetSpeed(2);
    text2.setText("Created by Jason Chiu");
    text2.setTargetA(255);
    text2.setTargetSpeed(2);
    text1.gotoTarget();
    text2.gotoTarget();
    line = 2;
  } else if (line == 2) {
    text1a.setText("Current Version: " + version);
    text1a.setTargetA(255);
    text1a.setTargetSpeed(4);
    text2a.setText("Released: " + year + "." + month + "." + day + " on www.winamp.com");
    text2a.setTargetA(255);
    text2a.setTargetSpeed(4);
    text1a.gotoTarget();
    text2a.gotoTarget();
    line = 3;
  } else if (line == 3) {
    text1.setText("SOURCES USED:");
    text1.setTargetA(255);
    text1.setTargetSpeed(4);
    text2.setText("Frisbee Monkey for the following scripts: drawer, eq, bassslider,");
    text2.setTargetA(255);
    text2.setTargetSpeed(4);
    text4.setText("trebleslider, mute, oldtimer, stopaftersong, and standardframe.");
    text4.setTargetA(255);
    text4.setTargetSpeed(4);
    text1.gotoTarget();
    text2.gotoTarget();
    text4.gotoTarget();
    line = 4;
  } else if (line == 4) {
    text1a.setText("SOURCES USED:");
    text1a.setTargetA(255);
    text1a.setTargetSpeed(2);
    text2a.setText("Digitalhigh for the seekbuttons script.");
    text2a.setTargetA(255);
    text2a.setTargetSpeed(2);
    text4a.setText("iPlayTheSpoons for the Open Source Notifier");
    text4a.setTargetA(255);
    text4a.setTargetSpeed(2);
    text1a.gotoTarget();
    text2a.gotoTarget();
    text4a.gotoTarget();
    line = 5;
  } else if (line == 5) {
    text1.setText("SOURCES USED:");
    text1.setTargetA(255);
    text1.setTargetSpeed(4);
    text2.setText("ThePlague for the scripts: sonfinfoparse, winshademenu, about,");
    text2.setTargetA(255);
    text2.setTargetSpeed(4);
    text4.setText("and all codes related to skin configuration/options.");
    text4.setTargetA(255);
    text4.setTargetSpeed(2);
    text1.gotoTarget();
    text2.gotoTarget();
    text4.gotoTarget();
    line = 6;
  } else if (line == 6) {
    text1a.setText("And let's not forget the guys at Nullsoft for their");
    text1a.setTargetA(255);
    text1a.setTargetSpeed(4);
    text2a.setText("Winamp 3 SimpleTutorial and ComlexTutorial skins.");
    text2a.setTargetA(255);
    text2a.setTargetSpeed(4);
    text1a.gotoTarget();
    text2a.gotoTarget();
    line = 7;
  } else if (line == 7) {
    text3.setText("Thanks a million!");
    text3.setTargetA(255);
    text3.setTargetSpeed(4);
    text3.gotoTarget();
    line = 8;
  } else if (line == 8) {
    text3a.setText("...and thank you viewers, for your input - much appreciated.");
    text3a.setTargetA(255);
    text3a.setTargetSpeed(4);
    text3a.gotoTarget();
    line = 9;
  } else if (line == 9) {
    text1.setText("Visit frisbeemonkey.com and forums.winamp.com");
    text1.setTargetA(255);
    text1.setTargetSpeed(4);
    text2.setText("for open-source scripts.");
    text2.setTargetA(255);
    text2.setTargetSpeed(4);
    text1.gotoTarget();
    text2.gotoTarget();
    line = 10;
  } else if (line == 10) {
    text3a.setText("\"Thank God for open source.\"");
    text3a.setTargetA(255);
    text3a.setTargetSpeed(3);
    text3a.gotoTarget();
    line = 11;
  } else if (line == 11) {
    text3.setText("\"Let's make sure history never forgets the name: Winamp.\"");
    text3.setTargetA(255);
    text3.setTargetSpeed(4);
    text3.gotoTarget();
    line = 12;
  } else if (line == 12) {
    text3a.setText("");
    text3a.setTargetA(255);
    text3a.setTargetSpeed(3);
    text3a.gotoTarget();
    line = 1;
  }
}

text1.onTargetReached() {
  if (text1.getAlpha() == 255) timer1.start();
}

text1a.onTargetReached() {
  if (text1a.getAlpha() == 255) timer1.start();
}

text3.onTargetReached() {
  if (text3.getAlpha() == 255) timer1.start();
}

text3a.onTargetReached() {
  if (text3a.getAlpha() == 255) timer1.start();
}
